# ⚖ Portal Escritório Modelo — UNIFAC

Portal web para gestão jurídica de um escritório modelo universitário.  
Desenvolvido como projeto acadêmico com Python puro, do backend ao frontend.

---

## 🏗 Arquitetura

```
┌─────────────────────────────────────────────┐
│              Railway Cloud                  │
│                                             │
│  ┌─────────────────────────────────────┐   │
│  │    NiceGUI (Frontend Python)         │   │
│  │  Login · Clientes · Processos ·     │   │
│  │  Audiências · Relatório             │   │
│  └──────────────┬──────────────────────┘   │
│                 │ HTTP interno              │
│  ┌──────────────▼──────────────────────┐   │
│  │    FastAPI (Backend Python)          │   │
│  │  JWT Auth · CRUD · Relatórios       │   │
│  └──────────────┬──────────────────────┘   │
│                 │ Motor (async)             │
│  ┌──────────────▼──────────────────────┐   │
│  │    MongoDB Atlas (NoSQL)             │   │
│  │  users · clientes · processos ·     │   │
│  │  audiencias                         │   │
│  └─────────────────────────────────────┘   │
└─────────────────────────────────────────────┘
```

## 🛠 Stack Tecnológica

| Camada | Tecnologia | Por quê |
|--------|-----------|---------|
| Frontend | **NiceGUI** | Framework Python web — sem HTML/JS manual |
| Backend | **FastAPI** | Async, validação automática, docs OpenAPI |
| Banco de dados | **MongoDB** (Motor async) | Documentos jurídicos com estrutura variável |
| Autenticação | **JWT** (python-jose) + **bcrypt** | Stateless, seguro, padrão de mercado |
| Cloud | **Railway** | Deploy gratuito via GitHub, variáveis de ambiente |
| Repositório | **GitHub** | CI/CD automático para Railway |

## 📁 Estrutura de Pastas

```
escritorio_modelo/
├── main.py                    # Ponto de entrada único
├── requirements.txt           # Dependências Python
├── Dockerfile                 # Container para Railway
├── railway.json               # Configuração de deploy
├── .env.example               # Template de variáveis
├── backend/
│   ├── main.py                # App FastAPI
│   ├── core/
│   │   ├── config.py          # Configurações (pydantic-settings)
│   │   ├── database.py        # Conexão MongoDB (Motor)
│   │   └── security.py        # JWT + bcrypt
│   ├── models/
│   │   └── schemas.py         # Schemas Pydantic
│   └── routers/
│       ├── auth.py            # Login e registro
│       ├── clientes.py        # CRUD clientes
│       ├── processos.py       # CRUD processos
│       ├── audiencias.py      # CRUD audiências
│       └── relatorio.py       # Relatório operacional
└── frontend/
    └── app.py                 # App NiceGUI (todas as páginas)
```

## 🚀 Como Executar Localmente

### 1. Pré-requisitos
- Python 3.11+
- MongoDB Atlas (conta gratuita) ou MongoDB local
- Git

### 2. Clone e configure

```bash
git clone https://github.com/SEU_USUARIO/escritorio-modelo.git
cd escritorio-modelo
cp .env.example .env
# Edite .env com sua MONGO_URI e SECRET_KEY
```

### 3. Instale dependências

```bash
pip install -r requirements.txt
```

### 4. Execute

```bash
python main.py
```

Acesse: http://localhost:8080

A documentação da API estará em: http://localhost:8080/docs

---

## ☁️ Deploy no Railway

### 1. MongoDB Atlas (gratuito)
1. Acesse https://cloud.mongodb.com
2. Crie cluster gratuito (M0)
3. Em "Database Access": crie usuário e senha
4. Em "Network Access": adicione `0.0.0.0/0`
5. Copie a connection string: `mongodb+srv://user:pass@cluster.mongodb.net/escritorio`

### 2. GitHub
```bash
git init
git add .
git commit -m "feat: portal escritório modelo inicial"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/escritorio-modelo.git
git push -u origin main
```

### 3. Railway
1. Acesse https://railway.app (login com GitHub — gratuito)
2. "New Project" → "Deploy from GitHub repo"
3. Selecione o repositório
4. Em "Variables", adicione:
   ```
   MONGO_URI=mongodb+srv://...
   SECRET_KEY=sua_chave_aleatoria_longa
   PORT=8080
   ```
5. Railway fará o deploy automático a cada `git push`!

---

## 📋 Funcionalidades

### Autenticação
- Registro de novo usuário (nome, e-mail, senha, perfil, matrícula)
- Login com JWT
- Perfis: Administrador, Advogado, Estagiário

### Aba 1 — Clientes (CRUD)
- Cadastrar cliente (nome, CPF/CNPJ, e-mail, telefone, endereço)
- Listar com busca por nome ou CPF/CNPJ
- Editar e remover clientes

### Aba 2 — Processos (CRUD)
- Cadastrar processo (número CNJ, tipo de ação, vara, comarca, cliente, advogado)
- Filtrar por status e busca livre
- Gerenciar status (Ativo, Suspenso, Encerrado, Aguardando)

### Aba 3 — Audiências (CRUD)
- Agendar audiência vinculada a processo
- Tipos: Conciliação, Instrução, Julgamento, Virtual
- Controle de status: Agendada, Realizada, Cancelada

### Aba 4 — Relatório Operacional
- Cards de resumo: processos, clientes, audiências
- Gráfico de barras por status de processo
- Distribuição por tipo de audiência
- Lista de processos recentes
- Próximas audiências (30 dias)

---

## 🔑 API Endpoints

| Método | Rota | Descrição |
|--------|------|-----------|
| POST | `/api/auth/register` | Criar usuário |
| POST | `/api/auth/login` | Login (retorna JWT) |
| GET | `/api/auth/me` | Usuário atual |
| GET/POST | `/api/clientes/` | Listar/criar clientes |
| GET/PUT/DELETE | `/api/clientes/{id}` | Detalhar/editar/remover |
| GET/POST | `/api/processos/` | Listar/criar processos |
| GET/PUT/DELETE | `/api/processos/{id}` | Detalhar/editar/remover |
| GET/POST | `/api/audiencias/` | Listar/criar audiências |
| GET/PUT/DELETE | `/api/audiencias/{id}` | Detalhar/editar/remover |
| GET | `/api/relatorio/operacional` | Dashboard operacional |
| GET | `/docs` | Swagger UI (documentação interativa) |

---

## 🐍 Easter Egg: antigravity

O módulo `antigravity` do Google (incluso no Python desde 3.x) é importado na inicialização
e abre https://xkcd.com/353/ — o famoso quadrinho sobre Python.

---

## 📜 Licença

Projeto acadêmico — uso livre para fins educacionais.
