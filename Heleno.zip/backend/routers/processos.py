"""
backend/routers/processos.py
CRUD de Processos Jurídicos.

Processos são o núcleo do escritório modelo:
- Vinculados a um Cliente e a um Advogado Responsável
- Têm status (Ativo, Suspenso, Encerrado, Aguardando)
- Armazenam lista de documentos (nomes/links)
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from datetime import datetime, timezone
from typing import List, Optional
from bson import ObjectId

from ..core.database import get_db
from ..routers.auth import get_current_user
from ..models.schemas import ProcessoCreate, ProcessoUpdate, ProcessoOut, UserOut

router = APIRouter(prefix="/processos", tags=["Processos"])


async def _enrich(doc: dict, db) -> ProcessoOut:
    """Enriquece processo com nome do cliente e do advogado."""
    cliente_nome = None
    advogado_nome = None

    try:
        c = await db.clientes.find_one({"_id": ObjectId(doc.get("cliente_id", ""))})
        if c:
            cliente_nome = c["nome"]
    except Exception:
        pass

    try:
        a = await db.users.find_one({"_id": ObjectId(doc.get("advogado_responsavel_id", ""))})
        if a:
            advogado_nome = a["nome"]
    except Exception:
        pass

    return ProcessoOut(
        id=str(doc["_id"]),
        numero=doc["numero"],
        tipo_acao=doc["tipo_acao"],
        vara=doc["vara"],
        comarca=doc["comarca"],
        cliente_id=doc["cliente_id"],
        advogado_responsavel_id=doc["advogado_responsavel_id"],
        parte_contraria=doc["parte_contraria"],
        status=doc["status"],
        data_distribuicao=doc["data_distribuicao"],
        descricao=doc.get("descricao"),
        documentos=doc.get("documentos", []),
        criado_em=doc["criado_em"],
        atualizado_em=doc.get("atualizado_em"),
        cliente_nome=cliente_nome,
        advogado_nome=advogado_nome,
    )


@router.post("/", response_model=ProcessoOut, status_code=201)
async def criar_processo(
    data: ProcessoCreate,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    if await db.processos.find_one({"numero": data.numero}):
        raise HTTPException(status_code=409, detail="Número de processo já cadastrado")

    doc = {**data.model_dump(), "criado_em": datetime.now(timezone.utc)}
    # Converte date para string para serialização MongoDB
    doc["data_distribuicao"] = str(doc["data_distribuicao"])
    result = await db.processos.insert_one(doc)
    doc["_id"] = result.inserted_id
    return await _enrich(doc, db)


@router.get("/", response_model=List[ProcessoOut])
async def listar_processos(
    status: Optional[str] = None,
    cliente_id: Optional[str] = None,
    busca: Optional[str] = Query(None),
    skip: int = 0,
    limit: int = 50,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    filtro = {}
    if status:
        filtro["status"] = status
    if cliente_id:
        filtro["cliente_id"] = cliente_id
    if busca:
        filtro["$or"] = [
            {"numero": {"$regex": busca, "$options": "i"}},
            {"tipo_acao": {"$regex": busca, "$options": "i"}},
            {"parte_contraria": {"$regex": busca, "$options": "i"}},
        ]

    cursor = db.processos.find(filtro).skip(skip).limit(limit).sort("criado_em", -1)
    return [await _enrich(doc, db) async for doc in cursor]


@router.get("/{processo_id}", response_model=ProcessoOut)
async def detalhar_processo(
    processo_id: str,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    doc = await db.processos.find_one({"_id": ObjectId(processo_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Processo não encontrado")
    return await _enrich(doc, db)


@router.put("/{processo_id}", response_model=ProcessoOut)
async def atualizar_processo(
    processo_id: str,
    data: ProcessoUpdate,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    updates = {k: v for k, v in data.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Nenhum campo para atualizar")
    updates["atualizado_em"] = datetime.now(timezone.utc)
    result = await db.processos.update_one({"_id": ObjectId(processo_id)}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Processo não encontrado")
    doc = await db.processos.find_one({"_id": ObjectId(processo_id)})
    return await _enrich(doc, db)


@router.delete("/{processo_id}", status_code=204)
async def remover_processo(
    processo_id: str,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    result = await db.processos.delete_one({"_id": ObjectId(processo_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Processo não encontrado")
