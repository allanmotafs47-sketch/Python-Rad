"""
backend/routers/relatorio.py
Relatório Operacional — consolidação de métricas do escritório.

Usa agregações MongoDB ($group, $match) para calcular:
- Totais de processos por status
- Audiências próximas (próximos 30 dias)
- Tipos de audiência mais comuns
- Processos recentes
"""
from fastapi import APIRouter, Depends
from datetime import datetime, timezone, timedelta

from ..core.database import get_db
from ..routers.auth import get_current_user
from ..models.schemas import RelatorioData, UserOut

router = APIRouter(prefix="/relatorio", tags=["Relatório"])


@router.get("/operacional", response_model=RelatorioData)
async def relatorio_operacional(
    current_user: UserOut = Depends(get_current_user),
):
    """
    Retorna dashboard operacional completo.
    Todas as queries rodam em paralelo conceitual (motor async).
    """
    db = get_db()
    agora = datetime.now(timezone.utc)
    limite_proximas = agora + timedelta(days=30)

    # Totais simples
    total_processos = await db.processos.count_documents({})
    processos_ativos = await db.processos.count_documents({"status": "Ativo"})
    processos_encerrados = await db.processos.count_documents({"status": "Encerrado"})
    total_clientes = await db.clientes.count_documents({})
    total_audiencias = await db.audiencias.count_documents({})
    audiencias_proximas = await db.audiencias.count_documents({
        "data_hora": {"$gte": agora, "$lte": limite_proximas},
        "status": "Agendada",
    })

    # Processos por status (agregação $group)
    pipeline_status = [
        {"$group": {"_id": "$status", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ]
    processos_por_status = {}
    async for doc in db.processos.aggregate(pipeline_status):
        processos_por_status[doc["_id"]] = doc["count"]

    # Audiências por tipo
    pipeline_tipo = [
        {"$group": {"_id": "$tipo", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ]
    audiencias_por_tipo = {}
    async for doc in db.audiencias.aggregate(pipeline_tipo):
        audiencias_por_tipo[doc["_id"]] = doc["count"]

    # Processos mais recentes (últimos 5)
    processos_recentes = []
    async for doc in db.processos.find({}).sort("criado_em", -1).limit(5):
        processos_recentes.append({
            "id": str(doc["_id"]),
            "numero": doc.get("numero", ""),
            "tipo_acao": doc.get("tipo_acao", ""),
            "status": doc.get("status", ""),
            "criado_em": doc["criado_em"].isoformat() if isinstance(doc.get("criado_em"), datetime) else str(doc.get("criado_em", "")),
        })

    # Próximas audiências (próximos 30 dias)
    audiencias_proximas_lista = []
    async for doc in db.audiencias.find({
        "data_hora": {"$gte": agora, "$lte": limite_proximas},
        "status": "Agendada",
    }).sort("data_hora", 1).limit(5):
        audiencias_proximas_lista.append({
            "id": str(doc["_id"]),
            "tipo": doc.get("tipo", ""),
            "local": doc.get("local", ""),
            "data_hora": doc["data_hora"].isoformat() if isinstance(doc.get("data_hora"), datetime) else str(doc.get("data_hora", "")),
            "processo_id": doc.get("processo_id", ""),
        })

    return RelatorioData(
        total_processos=total_processos,
        processos_ativos=processos_ativos,
        processos_encerrados=processos_encerrados,
        total_clientes=total_clientes,
        total_audiencias=total_audiencias,
        audiencias_proximas=audiencias_proximas,
        processos_por_status=processos_por_status,
        audiencias_por_tipo=audiencias_por_tipo,
        processos_recentes=processos_recentes,
        audiencias_proximas_lista=audiencias_proximas_lista,
    )
