"""
backend/routers/auth.py
Endpoints de autenticação — registro e login.

Fluxo:
  POST /auth/register → cria usuário, retorna token
  POST /auth/login    → valida credenciais, retorna token JWT

O token é enviado pelo cliente no header:
  Authorization: Bearer <token>
"""
from fastapi import APIRouter, HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from datetime import datetime, timezone
from bson import ObjectId

from ..core.database import get_db
from ..core.security import hash_password, verify_password, create_access_token, decode_token
from ..models.schemas import UserCreate, UserLogin, UserOut, TokenResponse

router = APIRouter(prefix="/auth", tags=["Autenticação"])
security = HTTPBearer()


def _serialize_user(doc: dict) -> UserOut:
    """Converte documento MongoDB em UserOut (str id)."""
    return UserOut(
        id=str(doc["_id"]),
        nome=doc["nome"],
        email=doc["email"],
        role=doc["role"],
        matricula=doc.get("matricula"),
        criado_em=doc["criado_em"],
    )


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> UserOut:
    """
    Dependency injetada nos endpoints protegidos.
    Valida o Bearer token e retorna o usuário atual.
    """
    payload = decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Token inválido ou expirado")
    db = get_db()
    doc = await db.users.find_one({"_id": ObjectId(payload["sub"])})
    if not doc:
        raise HTTPException(status_code=401, detail="Usuário não encontrado")
    return _serialize_user(doc)


@router.post("/register", response_model=TokenResponse, status_code=201)
async def register(data: UserCreate):
    """
    Cria novo usuário.
    Verifica duplicidade de e-mail antes de inserir.
    Armazena senha como hash bcrypt — nunca em texto plano.
    """
    db = get_db()
    if await db.users.find_one({"email": data.email}):
        raise HTTPException(status_code=409, detail="E-mail já cadastrado")

    doc = {
        "nome": data.nome,
        "email": data.email,
        "senha_hash": hash_password(data.senha),
        "role": data.role,
        "matricula": data.matricula,
        "criado_em": datetime.now(timezone.utc),
    }
    result = await db.users.insert_one(doc)
    doc["_id"] = result.inserted_id

    token = create_access_token({"sub": str(result.inserted_id), "email": data.email, "role": data.role})
    return TokenResponse(access_token=token, user=_serialize_user(doc))


@router.post("/login", response_model=TokenResponse)
async def login(data: UserLogin):
    """
    Autentica usuário por e-mail + senha.
    Usa verify_password (bcrypt) para comparação segura.
    """
    db = get_db()
    doc = await db.users.find_one({"email": data.email})
    if not doc or not verify_password(data.senha, doc["senha_hash"]):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")

    token = create_access_token({"sub": str(doc["_id"]), "email": doc["email"], "role": doc["role"]})
    return TokenResponse(access_token=token, user=_serialize_user(doc))


@router.get("/me", response_model=UserOut)
async def me(current_user: UserOut = Depends(get_current_user)):
    """Retorna dados do usuário autenticado."""
    return current_user
