"""
backend/routers/clientes.py
CRUD completo de Clientes — a entidade central do escritório.

Endpoints:
  POST   /clientes/         → criar cliente
  GET    /clientes/         → listar (com busca por nome/cpf)
  GET    /clientes/{id}     → detalhar
  PUT    /clientes/{id}     → atualizar
  DELETE /clientes/{id}     → remover

Todos os endpoints exigem autenticação via JWT.
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from datetime import datetime, timezone
from typing import List, Optional
from bson import ObjectId

from ..core.database import get_db
from ..routers.auth import get_current_user
from ..models.schemas import ClienteCreate, ClienteUpdate, ClienteOut, UserOut

router = APIRouter(prefix="/clientes", tags=["Clientes"])


def _to_out(doc: dict) -> ClienteOut:
    return ClienteOut(
        id=str(doc["_id"]),
        nome=doc["nome"],
        cpf_cnpj=doc["cpf_cnpj"],
        email=doc.get("email"),
        telefone=doc.get("telefone"),
        endereco=doc.get("endereco"),
        observacoes=doc.get("observacoes"),
        criado_em=doc["criado_em"],
        atualizado_em=doc.get("atualizado_em"),
    )


@router.post("/", response_model=ClienteOut, status_code=201)
async def criar_cliente(
    data: ClienteCreate,
    current_user: UserOut = Depends(get_current_user),
):
    """Cadastra novo cliente. Verifica CPF/CNPJ duplicado."""
    db = get_db()
    if await db.clientes.find_one({"cpf_cnpj": data.cpf_cnpj}):
        raise HTTPException(status_code=409, detail="CPF/CNPJ já cadastrado")

    doc = {**data.model_dump(), "criado_em": datetime.now(timezone.utc)}
    result = await db.clientes.insert_one(doc)
    doc["_id"] = result.inserted_id
    return _to_out(doc)


@router.get("/", response_model=List[ClienteOut])
async def listar_clientes(
    busca: Optional[str] = Query(None, description="Busca por nome ou CPF/CNPJ"),
    skip: int = 0,
    limit: int = 50,
    current_user: UserOut = Depends(get_current_user),
):
    """
    Lista clientes com paginação.
    Busca por regex case-insensitive em nome e cpf_cnpj.
    """
    db = get_db()
    filtro = {}
    if busca:
        filtro = {
            "$or": [
                {"nome": {"$regex": busca, "$options": "i"}},
                {"cpf_cnpj": {"$regex": busca, "$options": "i"}},
            ]
        }
    cursor = db.clientes.find(filtro).skip(skip).limit(limit).sort("nome", 1)
    return [_to_out(doc) async for doc in cursor]


@router.get("/{cliente_id}", response_model=ClienteOut)
async def detalhar_cliente(
    cliente_id: str,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    doc = await db.clientes.find_one({"_id": ObjectId(cliente_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Cliente não encontrado")
    return _to_out(doc)


@router.put("/{cliente_id}", response_model=ClienteOut)
async def atualizar_cliente(
    cliente_id: str,
    data: ClienteUpdate,
    current_user: UserOut = Depends(get_current_user),
):
    """Atualização parcial (PATCH semântico com PUT)."""
    db = get_db()
    updates = {k: v for k, v in data.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Nenhum campo para atualizar")

    updates["atualizado_em"] = datetime.now(timezone.utc)
    result = await db.clientes.update_one(
        {"_id": ObjectId(cliente_id)}, {"$set": updates}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Cliente não encontrado")

    doc = await db.clientes.find_one({"_id": ObjectId(cliente_id)})
    return _to_out(doc)


@router.delete("/{cliente_id}", status_code=204)
async def remover_cliente(
    cliente_id: str,
    current_user: UserOut = Depends(get_current_user),
):
    """Remove cliente. Retorna 204 No Content em caso de sucesso."""
    db = get_db()
    result = await db.clientes.delete_one({"_id": ObjectId(cliente_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Cliente não encontrado")
