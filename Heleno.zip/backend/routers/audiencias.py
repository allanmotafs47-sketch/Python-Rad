"""
backend/routers/audiencias.py
CRUD de Audiências vinculadas a processos.
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from datetime import datetime, timezone
from typing import List, Optional
from bson import ObjectId

from ..core.database import get_db
from ..routers.auth import get_current_user
from ..models.schemas import AudienciaCreate, AudienciaUpdate, AudienciaOut, UserOut

router = APIRouter(prefix="/audiencias", tags=["Audiências"])


async def _enrich(doc: dict, db) -> AudienciaOut:
    processo_numero = None
    try:
        p = await db.processos.find_one({"_id": ObjectId(doc.get("processo_id", ""))})
        if p:
            processo_numero = p["numero"]
    except Exception:
        pass

    return AudienciaOut(
        id=str(doc["_id"]),
        processo_id=doc["processo_id"],
        data_hora=doc["data_hora"],
        tipo=doc["tipo"],
        local=doc["local"],
        status=doc["status"],
        observacoes=doc.get("observacoes"),
        criado_em=doc["criado_em"],
        processo_numero=processo_numero,
    )


@router.post("/", response_model=AudienciaOut, status_code=201)
async def criar_audiencia(
    data: AudienciaCreate,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    doc = {**data.model_dump(), "criado_em": datetime.now(timezone.utc)}
    result = await db.audiencias.insert_one(doc)
    doc["_id"] = result.inserted_id
    return await _enrich(doc, db)


@router.get("/", response_model=List[AudienciaOut])
async def listar_audiencias(
    processo_id: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    filtro = {}
    if processo_id:
        filtro["processo_id"] = processo_id
    if status:
        filtro["status"] = status
    cursor = db.audiencias.find(filtro).skip(skip).limit(limit).sort("data_hora", 1)
    return [await _enrich(doc, db) async for doc in cursor]


@router.get("/{audiencia_id}", response_model=AudienciaOut)
async def detalhar_audiencia(
    audiencia_id: str,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    doc = await db.audiencias.find_one({"_id": ObjectId(audiencia_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Audiência não encontrada")
    return await _enrich(doc, db)


@router.put("/{audiencia_id}", response_model=AudienciaOut)
async def atualizar_audiencia(
    audiencia_id: str,
    data: AudienciaUpdate,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    updates = {k: v for k, v in data.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Nenhum campo para atualizar")
    updates["atualizado_em"] = datetime.now(timezone.utc)
    result = await db.audiencias.update_one({"_id": ObjectId(audiencia_id)}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Audiência não encontrada")
    doc = await db.audiencias.find_one({"_id": ObjectId(audiencia_id)})
    return await _enrich(doc, db)


@router.delete("/{audiencia_id}", status_code=204)
async def remover_audiencia(
    audiencia_id: str,
    current_user: UserOut = Depends(get_current_user),
):
    db = get_db()
    result = await db.audiencias.delete_one({"_id": ObjectId(audiencia_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Audiência não encontrada")
