"""
backend/models/schemas.py
Schemas Pydantic — definem e validam os dados que entram e saem da API.

Pydantic v2 valida automaticamente tipos, tamanhos e formatos.
Cada entidade tem três variantes:
  - Base: campos comuns
  - Create: campos obrigatórios no momento de criação
  - Out: campos retornados ao cliente (nunca expõe senha)
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime, date
from enum import Enum


# ─── Enumerações ────────────────────────────────────────────────────────────

class UserRole(str, Enum):
    admin = "admin"
    advogado = "advogado"
    estagiario = "estagiario"

class StatusProcesso(str, Enum):
    ativo = "Ativo"
    suspenso = "Suspenso"
    encerrado = "Encerrado"
    aguardando = "Aguardando"

class TipoAudiencia(str, Enum):
    conciliacao = "Conciliação"
    instrucao = "Instrução"
    julgamento = "Julgamento"
    virtual = "Virtual"

class StatusAudiencia(str, Enum):
    agendada = "Agendada"
    realizada = "Realizada"
    cancelada = "Cancelada"


# ─── Usuários ────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    nome: str = Field(..., min_length=3, max_length=100)
    email: EmailStr
    senha: str = Field(..., min_length=6)
    role: UserRole = UserRole.estagiario
    matricula: Optional[str] = None

class UserOut(BaseModel):
    id: str
    nome: str
    email: str
    role: UserRole
    matricula: Optional[str] = None
    criado_em: datetime

class UserLogin(BaseModel):
    email: EmailStr
    senha: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ─── Clientes (CRUD completo) ─────────────────────────────────────────────────

class ClienteCreate(BaseModel):
    nome: str = Field(..., min_length=2, max_length=150)
    cpf_cnpj: str = Field(..., min_length=11, max_length=18)
    email: Optional[EmailStr] = None
    telefone: Optional[str] = None
    endereco: Optional[str] = None
    observacoes: Optional[str] = None

class ClienteUpdate(BaseModel):
    nome: Optional[str] = None
    email: Optional[EmailStr] = None
    telefone: Optional[str] = None
    endereco: Optional[str] = None
    observacoes: Optional[str] = None

class ClienteOut(ClienteCreate):
    id: str
    criado_em: datetime
    atualizado_em: Optional[datetime] = None


# ─── Processos ────────────────────────────────────────────────────────────────

class ProcessoCreate(BaseModel):
    numero: str = Field(..., description="Número do processo no formato CNJ")
    tipo_acao: str = Field(..., min_length=3)
    vara: str
    comarca: str
    cliente_id: str
    advogado_responsavel_id: str
    parte_contraria: str
    status: StatusProcesso = StatusProcesso.ativo
    data_distribuicao: date
    descricao: Optional[str] = None
    documentos: List[str] = []

class ProcessoUpdate(BaseModel):
    tipo_acao: Optional[str] = None
    vara: Optional[str] = None
    status: Optional[StatusProcesso] = None
    descricao: Optional[str] = None
    documentos: Optional[List[str]] = None

class ProcessoOut(ProcessoCreate):
    id: str
    criado_em: datetime
    atualizado_em: Optional[datetime] = None
    cliente_nome: Optional[str] = None
    advogado_nome: Optional[str] = None


# ─── Audiências ───────────────────────────────────────────────────────────────

class AudienciaCreate(BaseModel):
    processo_id: str
    data_hora: datetime
    tipo: TipoAudiencia
    local: str
    status: StatusAudiencia = StatusAudiencia.agendada
    observacoes: Optional[str] = None

class AudienciaUpdate(BaseModel):
    data_hora: Optional[datetime] = None
    local: Optional[str] = None
    status: Optional[StatusAudiencia] = None
    observacoes: Optional[str] = None

class AudienciaOut(AudienciaCreate):
    id: str
    processo_numero: Optional[str] = None
    criado_em: datetime


# ─── Relatório ────────────────────────────────────────────────────────────────

class RelatorioData(BaseModel):
    total_processos: int
    processos_ativos: int
    processos_encerrados: int
    total_clientes: int
    total_audiencias: int
    audiencias_proximas: int
    processos_por_status: dict
    audiencias_por_tipo: dict
    processos_recentes: List[dict]
    audiencias_proximas_lista: List[dict]
