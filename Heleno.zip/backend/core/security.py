"""
backend/core/security.py
Funções de segurança: hash de senhas (bcrypt) e tokens JWT.

Por que JWT?
  - Stateless: o servidor não precisa guardar sessão em memória.
  - O token carrega as claims do usuário (id, email, role).
  - Expiração configurável via ACCESS_TOKEN_EXPIRE_MINUTES.
"""
from datetime import datetime, timedelta, timezone
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from .config import get_settings

settings = get_settings()

# CryptContext usando bcrypt — algoritmo seguro e adaptativo
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Gera hash bcrypt da senha em texto plano."""
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    """Compara senha em texto plano com hash armazenado."""
    return pwd_context.verify(plain, hashed)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Cria token JWT assinado com SECRET_KEY.
    data: dict com pelo menos {'sub': user_id, 'email': ..., 'role': ...}
    """
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=settings.access_token_expire_minutes)
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)


def decode_token(token: str) -> Optional[dict]:
    """
    Decodifica e valida token JWT.
    Retorna o payload ou None se inválido/expirado.
    """
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        return payload
    except JWTError:
        return None
