"""
backend/core/database.py
Conexão assíncrona com MongoDB usando Motor.

Por que MongoDB (NoSQL)?
  - Documentos JSON nativos — ideal para armazenar processos jurídicos com
    estruturas variáveis (tipos de ação, partes diferentes, documentos anexos).
  - Motor: driver assíncrono oficial para MongoDB + Python asyncio/FastAPI.
  - Escalabilidade horizontal nativa.

Por que Motor em vez de PyMongo?
  - FastAPI é 100% async; Motor garante que as queries ao banco não bloqueiem
    o event loop.
"""
from motor.motor_asyncio import AsyncIOMotorClient
from .config import get_settings

settings = get_settings()

# Cliente único (singleton) reutilizado em todo o ciclo de vida da aplicação
_client: AsyncIOMotorClient = None


def get_client() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(settings.mongo_uri)
    return _client


def get_db():
    """Retorna o banco 'escritorio'. Collections criadas automaticamente."""
    return get_client()["escritorio"]
