"""
backend/main.py
Ponto de entrada do backend FastAPI.

FastAPI foi escolhido por:
- Performance (baseado em Starlette + asyncio)
- Documentação automática via OpenAPI (Swagger UI em /docs)
- Validação automática via Pydantic
- Suporte nativo a async/await (essencial com Motor/MongoDB)
"""
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import auth, clientes, processos, audiencias, relatorio

app = FastAPI(
    title="Escritório Modelo — API",
    description="Backend do portal do Escritório Modelo Universitário",
    version="1.0.0",
    docs_url="/docs",       # Swagger UI disponível em /api/docs
    redoc_url="/redoc",
)

# ─── CORS ─────────────────────────────────────────────────────────────────────
# Permite que o frontend NiceGUI (mesmo processo ou porta diferente) acesse a API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # Em produção: especifique o domínio do frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routers ──────────────────────────────────────────────────────────────────
app.include_router(auth.router,       prefix="/api")
app.include_router(clientes.router,   prefix="/api")
app.include_router(processos.router,  prefix="/api")
app.include_router(audiencias.router, prefix="/api")
app.include_router(relatorio.router,  prefix="/api")


@app.get("/", tags=["Root"])
async def root():
    return {
        "app": "Escritório Modelo API",
        "versao": "1.0.0",
        "docs": "/docs",
        "status": "online",
    }


@app.get("/health", tags=["Health"])
async def health():
    """Endpoint de saúde usado pelo Railway para verificar disponibilidade."""
    return {"status": "healthy"}
