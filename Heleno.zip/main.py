"""
main.py — Ponto de entrada único da aplicação.

Em produção (Railway), um único processo sobe:
  - FastAPI (backend) via uvicorn em /api/*
  - NiceGUI (frontend) nas demais rotas

Por que unificado?
  - Railway oferece um único serviço gratuito por projeto.
  - Evita problemas de CORS entre domínios diferentes.
  - Simplifica variáveis de ambiente e deploy.

Como funciona a integração NiceGUI + FastAPI?
  - NiceGUI expõe uma função `ui.run_with` que monta o app NiceGUI
    como sub-aplicação do FastAPI via `app.mount()`.
  - Uvicorn serve tudo na mesma porta.
"""
import os
import uvicorn
from nicegui import ui, app as nicegui_app

# Importa o app FastAPI
from backend.main import app as fastapi_app

# Importa as páginas do frontend (registra as rotas @ui.page)
import frontend.app  # noqa: F401

# Monta o NiceGUI dentro do FastAPI
ui.run_with(
    fastapi_app,
    title="Escritório Modelo — UNIFAC",
    favicon="⚖",
    dark=False,
    storage_secret=os.getenv("SECRET_KEY", "storage_secret_dev"),
)

if __name__ == "__main__":
    uvicorn.run(
        "main:fastapi_app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8080)),
        reload=False,
    )
