"""
frontend/app.py
Frontend completo do Portal Escritório Modelo usando NiceGUI.

Por que NiceGUI?
  - Framework Python puro para web UI (sem escrever HTML/JS/CSS manualmente)
  - Baseado em Vue.js + Quasar por baixo dos panos
  - Roda no mesmo processo Python ou em servidor separado
  - Ideal para aplicações internas e portais universitários

Estrutura de páginas:
  /          → Login
  /register  → Cadastro de novo usuário
  /dashboard → Painel principal com 4 abas:
               [1] Clientes (CRUD)
               [2] Processos (CRUD)
               [3] Audiências (CRUD)
               [4] Relatório Operacional

Comunicação com backend: httpx (HTTP client async)
Cores: azul (#1565C0), preto (#0D0D0D), branco (#FFFFFF)
"""

import os
import httpx
from datetime import datetime
from nicegui import ui, app as nicegui_app

# ─── Configuração ─────────────────────────────────────────────────────────────
API = os.getenv("API_BASE_URL", "http://localhost:8000")

# Paleta de cores
BLUE    = "#1565C0"
BLUE_LT = "#1976D2"
BLUE_DK = "#0D47A1"
BLACK   = "#0D0D0D"
WHITE   = "#FFFFFF"
GRAY    = "#F5F7FA"
GRAY2   = "#E3E8EF"
RED     = "#C62828"
GREEN   = "#2E7D32"


# ─── Estado Global (substituiria sessionStorage) ───────────────────────────────
class State:
    token: str = ""
    user: dict = {}

state = State()


# ─── Helpers de API ───────────────────────────────────────────────────────────

def headers():
    return {"Authorization": f"Bearer {state.token}"}

async def api_get(path: str) -> dict | list | None:
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{API}/api{path}", headers=headers(), timeout=10)
            if r.status_code == 200:
                return r.json()
            return None
    except Exception:
        return None

async def api_post(path: str, data: dict) -> dict | None:
    try:
        async with httpx.AsyncClient() as client:
            r = await client.post(f"{API}/api{path}", json=data, headers=headers(), timeout=10)
            if r.status_code in (200, 201):
                return r.json()
            return None
    except Exception:
        return None

async def api_put(path: str, data: dict) -> dict | None:
    try:
        async with httpx.AsyncClient() as client:
            r = await client.put(f"{API}/api{path}", json=data, headers=headers(), timeout=10)
            if r.status_code == 200:
                return r.json()
            return None
    except Exception:
        return None

async def api_delete(path: str) -> bool:
    try:
        async with httpx.AsyncClient() as client:
            r = await client.delete(f"{API}/api{path}", headers=headers(), timeout=10)
            return r.status_code == 204
    except Exception:
        return False


# ─── CSS Global ───────────────────────────────────────────────────────────────

def inject_global_styles():
    ui.add_head_html("""
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
      * { font-family: 'Inter', sans-serif; box-sizing: border-box; }
      body { background: #F5F7FA; margin: 0; }
      .topbar { background: #0D47A1; color: white; padding: 0 24px;
                display: flex; align-items: center; justify-content: space-between;
                height: 60px; box-shadow: 0 2px 8px rgba(0,0,0,0.3); }
      .topbar-title { font-size: 18px; font-weight: 700; letter-spacing: 0.5px; }
      .topbar-user { font-size: 13px; opacity: 0.85; }
      .card-stat { background: white; border-radius: 10px; padding: 20px;
                   box-shadow: 0 1px 4px rgba(0,0,0,0.08);
                   border-left: 4px solid #1565C0; }
      .stat-value { font-size: 28px; font-weight: 700; color: #1565C0; }
      .stat-label { font-size: 12px; color: #666; margin-top: 4px; text-transform: uppercase; }
      .section-title { font-size: 16px; font-weight: 600; color: #0D47A1;
                       border-bottom: 2px solid #1565C0; padding-bottom: 8px; margin-bottom: 16px; }
      .badge-ativo { background: #E8F5E9; color: #2E7D32; padding: 2px 10px;
                     border-radius: 12px; font-size: 12px; font-weight: 500; }
      .badge-encerrado { background: #FFEBEE; color: #C62828; padding: 2px 10px;
                         border-radius: 12px; font-size: 12px; font-weight: 500; }
      .badge-suspenso { background: #FFF8E1; color: #F57F17; padding: 2px 10px;
                        border-radius: 12px; font-size: 12px; font-weight: 500; }
      .badge-aguardando { background: #E3F2FD; color: #1565C0; padding: 2px 10px;
                          border-radius: 12px; font-size: 12px; font-weight: 500; }
    </style>
    """)


# ─── COMPONENTES REUTILIZÁVEIS ────────────────────────────────────────────────

def topbar(subtitle: str = ""):
    with ui.element("div").classes("topbar"):
        with ui.element("div"):
            ui.element("span").classes("topbar-title").style("color:white").set_text(
                "⚖ Escritório Modelo — UNIFAC"
            )
            if subtitle:
                ui.element("span").style("color:rgba(255,255,255,0.7);font-size:13px;margin-left:12px").set_text(f"/ {subtitle}")
        with ui.element("div").classes("topbar-user"):
            nome = state.user.get("nome", "Usuário")
            role = state.user.get("role", "")
            ui.element("span").style("color:white").set_text(f"👤 {nome} ({role})")
            ui.button("Sair", on_click=lambda: (state.__init__(), ui.navigate.to("/"))).props(
                "flat dense"
            ).style("color:rgba(255,255,255,0.8);margin-left:16px;font-size:13px")


def stat_card(label: str, value: str, cor: str = BLUE):
    with ui.element("div").classes("card-stat").style(f"border-left-color:{cor}"):
        ui.element("div").classes("stat-value").style(f"color:{cor}").set_text(value)
        ui.element("div").classes("stat-label").set_text(label)


def notify_ok(msg: str):
    ui.notify(msg, type="positive", position="top-right", timeout=3000)

def notify_err(msg: str):
    ui.notify(msg, type="negative", position="top-right", timeout=4000)


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA DE LOGIN
# ════════════════════════════════════════════════════════════════════════════

@ui.page("/")
def login_page():
    inject_global_styles()
    ui.add_head_html("<title>Login — Escritório Modelo</title>")

    with ui.element("div").style(
        "min-height:100vh;display:flex;align-items:center;justify-content:center;"
        f"background:linear-gradient(135deg,{BLUE_DK} 0%,{BLUE} 50%,{BLACK} 100%)"
    ):
        with ui.card().style(
            "width:380px;padding:40px;border-radius:16px;"
            "box-shadow:0 20px 60px rgba(0,0,0,0.4)"
        ):
            # Logo / Header
            with ui.element("div").style("text-align:center;margin-bottom:32px"):
                ui.element("div").style(
                    f"font-size:48px;margin-bottom:8px"
                ).set_text("⚖")
                ui.element("div").style(
                    f"font-size:20px;font-weight:700;color:{BLUE_DK}"
                ).set_text("Escritório Modelo")
                ui.element("div").style(
                    "font-size:13px;color:#666;margin-top:4px"
                ).set_text("Portal Jurídico Universitário")

            email = ui.input(
                label="E-mail",
                placeholder="seu@email.com",
            ).style("width:100%").props("outlined")

            senha = ui.input(
                label="Senha",
                password=True,
                password_toggle_button=True,
            ).style("width:100%;margin-top:12px").props("outlined")

            async def fazer_login():
                if not email.value or not senha.value:
                    notify_err("Preencha e-mail e senha")
                    return
                result = await api_post("/auth/login", {
                    "email": email.value,
                    "senha": senha.value,
                })
                if result:
                    state.token = result["access_token"]
                    state.user = result["user"]
                    ui.navigate.to("/dashboard")
                else:
                    notify_err("Credenciais inválidas")

            ui.button("Entrar", on_click=fazer_login).style(
                f"width:100%;margin-top:20px;background:{BLUE};color:white;"
                "font-weight:600;border-radius:8px;height:44px;font-size:15px"
            ).props("unelevated")

            with ui.element("div").style("text-align:center;margin-top:16px"):
                ui.element("span").style("font-size:13px;color:#666").set_text("Não tem conta? ")
                ui.link("Criar conta", "/register").style(
                    f"font-size:13px;color:{BLUE};font-weight:600"
                )


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA DE CADASTRO
# ════════════════════════════════════════════════════════════════════════════

@ui.page("/register")
def register_page():
    inject_global_styles()
    ui.add_head_html("<title>Cadastro — Escritório Modelo</title>")

    with ui.element("div").style(
        "min-height:100vh;display:flex;align-items:center;justify-content:center;"
        f"background:linear-gradient(135deg,{BLUE_DK} 0%,{BLUE} 50%,{BLACK} 100%)"
    ):
        with ui.card().style(
            "width:420px;padding:40px;border-radius:16px;"
            "box-shadow:0 20px 60px rgba(0,0,0,0.4)"
        ):
            with ui.element("div").style("text-align:center;margin-bottom:28px"):
                ui.element("div").style("font-size:36px").set_text("⚖")
                ui.element("div").style(
                    f"font-size:20px;font-weight:700;color:{BLUE_DK}"
                ).set_text("Criar Conta")
                ui.element("div").style("font-size:13px;color:#666;margin-top:4px").set_text(
                    "Escritório Modelo — UNIFAC"
                )

            nome = ui.input("Nome completo").style("width:100%").props("outlined")
            email = ui.input("E-mail", placeholder="seu@email.com").style(
                "width:100%;margin-top:10px"
            ).props("outlined")
            matricula = ui.input("Matrícula (opcional)").style(
                "width:100%;margin-top:10px"
            ).props("outlined")
            role = ui.select(
                label="Perfil",
                options={"estagiario": "Estagiário", "advogado": "Advogado", "admin": "Administrador"},
                value="estagiario",
            ).style("width:100%;margin-top:10px").props("outlined")
            senha = ui.input("Senha (mín. 6 caracteres)", password=True, password_toggle_button=True).style(
                "width:100%;margin-top:10px"
            ).props("outlined")
            senha2 = ui.input("Confirmar senha", password=True).style(
                "width:100%;margin-top:10px"
            ).props("outlined")

            async def cadastrar():
                if not all([nome.value, email.value, senha.value]):
                    notify_err("Preencha todos os campos obrigatórios")
                    return
                if senha.value != senha2.value:
                    notify_err("Senhas não conferem")
                    return
                if len(senha.value) < 6:
                    notify_err("Senha deve ter pelo menos 6 caracteres")
                    return
                result = await api_post("/auth/register", {
                    "nome": nome.value,
                    "email": email.value,
                    "senha": senha.value,
                    "role": role.value,
                    "matricula": matricula.value or None,
                })
                if result:
                    state.token = result["access_token"]
                    state.user = result["user"]
                    notify_ok("Conta criada com sucesso!")
                    ui.navigate.to("/dashboard")
                else:
                    notify_err("Erro ao criar conta. E-mail pode já estar cadastrado.")

            ui.button("Criar Conta", on_click=cadastrar).style(
                f"width:100%;margin-top:20px;background:{BLUE};color:white;"
                "font-weight:600;border-radius:8px;height:44px;font-size:15px"
            ).props("unelevated")

            with ui.element("div").style("text-align:center;margin-top:12px"):
                ui.element("span").style("font-size:13px;color:#666").set_text("Já tem conta? ")
                ui.link("Entrar", "/").style(f"font-size:13px;color:{BLUE};font-weight:600")


# ════════════════════════════════════════════════════════════════════════════
# DASHBOARD PRINCIPAL (4 ABAS)
# ════════════════════════════════════════════════════════════════════════════

@ui.page("/dashboard")
async def dashboard_page():
    inject_global_styles()
    ui.add_head_html("<title>Dashboard — Escritório Modelo</title>")

    if not state.token:
        ui.navigate.to("/")
        return

    topbar()

    with ui.tabs().style(
        f"background:{WHITE};border-bottom:2px solid {BLUE};padding:0 24px"
    ).props("align=left") as tabs:
        tab_clientes   = ui.tab("Clientes",   icon="people")
        tab_processos  = ui.tab("Processos",  icon="gavel")
        tab_audiencias = ui.tab("Audiências", icon="event")
        tab_relatorio  = ui.tab("Relatório",  icon="bar_chart")

    with ui.tab_panels(tabs, value=tab_clientes).style("padding:24px;background:#F5F7FA"):

        # ─── ABA 1: CLIENTES ─────────────────────────────────────────────
        with ui.tab_panel(tab_clientes):
            await aba_clientes()

        # ─── ABA 2: PROCESSOS ────────────────────────────────────────────
        with ui.tab_panel(tab_processos):
            await aba_processos()

        # ─── ABA 3: AUDIÊNCIAS ───────────────────────────────────────────
        with ui.tab_panel(tab_audiencias):
            await aba_audiencias()

        # ─── ABA 4: RELATÓRIO ────────────────────────────────────────────
        with ui.tab_panel(tab_relatorio):
            await aba_relatorio()


# ─── ABA CLIENTES ────────────────────────────────────────────────────────────

async def aba_clientes():
    ui.element("div").classes("section-title").set_text("👥 Gestão de Clientes")

    # Formulário de cadastro
    with ui.expansion("➕ Novo Cliente", icon="person_add").style(
        f"background:white;border-radius:10px;margin-bottom:16px;"
        "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
    ):
        with ui.grid(columns=2).style("gap:12px;padding:16px"):
            f_nome     = ui.input("Nome completo *").props("outlined").style("width:100%")
            f_cpf      = ui.input("CPF ou CNPJ *").props("outlined").style("width:100%")
            f_email    = ui.input("E-mail").props("outlined").style("width:100%")
            f_tel      = ui.input("Telefone").props("outlined").style("width:100%")
            f_end      = ui.input("Endereço").props("outlined").style("width:100%")
            f_obs      = ui.input("Observações").props("outlined").style("width:100%")

        tabela_ref = {"ref": None}

        async def salvar_cliente():
            if not f_nome.value or not f_cpf.value:
                notify_err("Nome e CPF/CNPJ são obrigatórios")
                return
            result = await api_post("/clientes/", {
                "nome": f_nome.value,
                "cpf_cnpj": f_cpf.value,
                "email": f_email.value or None,
                "telefone": f_tel.value or None,
                "endereco": f_end.value or None,
                "observacoes": f_obs.value or None,
            })
            if result:
                notify_ok("Cliente cadastrado com sucesso!")
                for f in [f_nome, f_cpf, f_email, f_tel, f_end, f_obs]:
                    f.set_value("")
                await carregar_clientes()
            else:
                notify_err("Erro ao cadastrar. CPF/CNPJ pode já estar cadastrado.")

        ui.button("Salvar Cliente", on_click=salvar_cliente, icon="save").style(
            f"background:{BLUE};color:white;margin:0 16px 16px;border-radius:8px"
        ).props("unelevated")

    # Busca
    with ui.row().style("align-items:center;gap:12px;margin-bottom:16px"):
        busca = ui.input("🔍 Buscar por nome ou CPF/CNPJ").props("outlined").style("width:320px")
        ui.button("Buscar", on_click=lambda: ui.run_javascript("window._buscaClientes()")).style(
            f"background:{BLUE};color:white;border-radius:8px"
        ).props("unelevated")

    # Tabela de clientes
    clientes_container = ui.element("div").style("width:100%")

    async def carregar_clientes(q: str = ""):
        clientes_container.clear()
        path = f"/clientes/?limit=100"
        if q:
            path += f"&busca={q}"
        dados = await api_get(path) or []

        with clientes_container:
            if not dados:
                ui.element("div").style("color:#888;padding:24px;text-align:center").set_text(
                    "Nenhum cliente encontrado."
                )
                return

            columns = [
                {"name": "nome",    "label": "Nome",       "field": "nome",    "sortable": True},
                {"name": "cpf",     "label": "CPF/CNPJ",   "field": "cpf_cnpj"},
                {"name": "email",   "label": "E-mail",      "field": "email"},
                {"name": "tel",     "label": "Telefone",    "field": "telefone"},
                {"name": "acoes",   "label": "Ações",       "field": "id"},
            ]

            rows = [
                {
                    "id":       c["id"],
                    "nome":     c["nome"],
                    "cpf_cnpj": c["cpf_cnpj"],
                    "email":    c.get("email") or "—",
                    "telefone": c.get("telefone") or "—",
                }
                for c in dados
            ]

            table = ui.table(columns=columns, rows=rows, row_key="id").style(
                "width:100%;background:white;border-radius:10px;"
                "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
            ).props("flat bordered")

            table.add_slot("body-cell-acoes", """
                <q-td :props="props">
                    <q-btn flat dense icon="edit" color="primary"
                           @click="$parent.$emit('edit', props.row)" />
                    <q-btn flat dense icon="delete" color="negative"
                           @click="$parent.$emit('delete', props.row)" />
                </q-td>
            """)

            async def on_delete(e):
                ok = await api_delete(f"/clientes/{e.args['id']}")
                if ok:
                    notify_ok("Cliente removido!")
                    await carregar_clientes()
                else:
                    notify_err("Erro ao remover cliente")

            table.on("delete", on_delete)

    await carregar_clientes()


# ─── ABA PROCESSOS ───────────────────────────────────────────────────────────

async def aba_processos():
    ui.element("div").classes("section-title").set_text("⚖ Gestão de Processos")

    with ui.expansion("➕ Novo Processo", icon="add_circle").style(
        "background:white;border-radius:10px;margin-bottom:16px;"
        "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
    ):
        with ui.grid(columns=2).style("gap:12px;padding:16px"):
            f_num   = ui.input("Número do Processo (CNJ) *").props("outlined").style("width:100%")
            f_acao  = ui.input("Tipo de Ação *").props("outlined").style("width:100%")
            f_vara  = ui.input("Vara *").props("outlined").style("width:100%")
            f_com   = ui.input("Comarca *").props("outlined").style("width:100%")
            f_cid   = ui.input("ID do Cliente *").props("outlined").style("width:100%")
            f_adv   = ui.input("ID do Advogado Responsável *").props("outlined").style("width:100%")
            f_part  = ui.input("Parte Contrária *").props("outlined").style("width:100%")
            f_dist  = ui.input("Data de Distribuição (AAAA-MM-DD) *").props("outlined").style("width:100%")
            f_status = ui.select(
                "Status",
                options=["Ativo", "Suspenso", "Encerrado", "Aguardando"],
                value="Ativo",
            ).props("outlined").style("width:100%")
            f_desc  = ui.input("Descrição").props("outlined").style("width:100%")

        async def salvar_processo():
            campos = [f_num.value, f_acao.value, f_vara.value, f_com.value,
                      f_cid.value, f_adv.value, f_part.value, f_dist.value]
            if not all(campos):
                notify_err("Preencha todos os campos obrigatórios")
                return
            result = await api_post("/processos/", {
                "numero":                   f_num.value,
                "tipo_acao":                f_acao.value,
                "vara":                     f_vara.value,
                "comarca":                  f_com.value,
                "cliente_id":               f_cid.value,
                "advogado_responsavel_id":  f_adv.value,
                "parte_contraria":          f_part.value,
                "data_distribuicao":        f_dist.value,
                "status":                   f_status.value,
                "descricao":                f_desc.value or None,
                "documentos":               [],
            })
            if result:
                notify_ok("Processo cadastrado!")
                await carregar_processos()
            else:
                notify_err("Erro ao cadastrar processo")

        ui.button("Salvar Processo", on_click=salvar_processo, icon="save").style(
            f"background:{BLUE};color:white;margin:0 16px 16px;border-radius:8px"
        ).props("unelevated")

    # Filtros
    with ui.row().style("align-items:center;gap:12px;margin-bottom:16px"):
        filtro_status = ui.select(
            "Filtrar por status",
            options=["Todos", "Ativo", "Suspenso", "Encerrado", "Aguardando"],
            value="Todos",
        ).props("outlined").style("width:200px")
        busca_p = ui.input("🔍 Buscar número ou tipo").props("outlined").style("width:280px")
        ui.button("Filtrar", on_click=lambda: ui.run_javascript("")).style(
            f"background:{BLUE};color:white;border-radius:8px"
        ).props("unelevated")

    processos_container = ui.element("div").style("width:100%")

    STATUS_BADGE = {
        "Ativo":       "badge-ativo",
        "Encerrado":   "badge-encerrado",
        "Suspenso":    "badge-suspenso",
        "Aguardando":  "badge-aguardando",
    }

    async def carregar_processos():
        processos_container.clear()
        path = "/processos/?limit=100"
        s = filtro_status.value
        if s and s != "Todos":
            path += f"&status={s}"
        if busca_p.value:
            path += f"&busca={busca_p.value}"
        dados = await api_get(path) or []

        with processos_container:
            if not dados:
                ui.element("div").style("color:#888;padding:24px;text-align:center").set_text(
                    "Nenhum processo encontrado."
                )
                return
            columns = [
                {"name": "numero",   "label": "Número",           "field": "numero",   "sortable": True},
                {"name": "acao",     "label": "Tipo de Ação",      "field": "tipo_acao"},
                {"name": "cliente",  "label": "Cliente",           "field": "cliente_nome"},
                {"name": "status",   "label": "Status",            "field": "status"},
                {"name": "dist",     "label": "Distribuição",      "field": "data_distribuicao"},
                {"name": "acoes",    "label": "Ações",             "field": "id"},
            ]
            rows = [
                {
                    "id":               p["id"],
                    "numero":           p["numero"],
                    "tipo_acao":        p["tipo_acao"],
                    "cliente_nome":     p.get("cliente_nome") or "—",
                    "status":           p["status"],
                    "data_distribuicao": p.get("data_distribuicao", "")[:10],
                }
                for p in dados
            ]
            table = ui.table(columns=columns, rows=rows, row_key="id").style(
                "width:100%;background:white;border-radius:10px;"
                "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
            ).props("flat bordered")

            table.add_slot("body-cell-acoes", """
                <q-td :props="props">
                    <q-btn flat dense icon="delete" color="negative"
                           @click="$parent.$emit('delete', props.row)" />
                </q-td>
            """)

            async def del_proc(e):
                ok = await api_delete(f"/processos/{e.args['id']}")
                if ok:
                    notify_ok("Processo removido!")
                    await carregar_processos()
                else:
                    notify_err("Erro ao remover")

            table.on("delete", del_proc)

    filtro_status.on_value_change(lambda _: ui.run_javascript(""))
    await carregar_processos()


# ─── ABA AUDIÊNCIAS ──────────────────────────────────────────────────────────

async def aba_audiencias():
    ui.element("div").classes("section-title").set_text("📅 Gestão de Audiências")

    with ui.expansion("➕ Nova Audiência", icon="event_available").style(
        "background:white;border-radius:10px;margin-bottom:16px;"
        "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
    ):
        with ui.grid(columns=2).style("gap:12px;padding:16px"):
            f_pid   = ui.input("ID do Processo *").props("outlined").style("width:100%")
            f_tipo  = ui.select(
                "Tipo *",
                options=["Conciliação", "Instrução", "Julgamento", "Virtual"],
                value="Conciliação",
            ).props("outlined").style("width:100%")
            f_data  = ui.input("Data e Hora (AAAA-MM-DDTHH:MM) *").props("outlined").style("width:100%")
            f_local = ui.input("Local *").props("outlined").style("width:100%")
            f_status_a = ui.select(
                "Status",
                options=["Agendada", "Realizada", "Cancelada"],
                value="Agendada",
            ).props("outlined").style("width:100%")
            f_obs_a = ui.input("Observações").props("outlined").style("width:100%")

        async def salvar_audiencia():
            if not all([f_pid.value, f_data.value, f_local.value]):
                notify_err("Preencha os campos obrigatórios")
                return
            # Normaliza datetime
            dt = f_data.value
            if "T" not in dt:
                dt += "T00:00:00"
            result = await api_post("/audiencias/", {
                "processo_id": f_pid.value,
                "data_hora":   dt,
                "tipo":        f_tipo.value,
                "local":       f_local.value,
                "status":      f_status_a.value,
                "observacoes": f_obs_a.value or None,
            })
            if result:
                notify_ok("Audiência agendada!")
                await carregar_audiencias()
            else:
                notify_err("Erro ao agendar audiência")

        ui.button("Agendar Audiência", on_click=salvar_audiencia, icon="save").style(
            f"background:{BLUE};color:white;margin:0 16px 16px;border-radius:8px"
        ).props("unelevated")

    audiencias_container = ui.element("div").style("width:100%")

    async def carregar_audiencias():
        audiencias_container.clear()
        dados = await api_get("/audiencias/?limit=100") or []
        with audiencias_container:
            if not dados:
                ui.element("div").style("color:#888;padding:24px;text-align:center").set_text(
                    "Nenhuma audiência encontrada."
                )
                return
            columns = [
                {"name": "processo",  "label": "Processo",      "field": "processo_numero"},
                {"name": "tipo",      "label": "Tipo",           "field": "tipo"},
                {"name": "data",      "label": "Data e Hora",    "field": "data_hora"},
                {"name": "local",     "label": "Local",          "field": "local"},
                {"name": "status",    "label": "Status",         "field": "status"},
                {"name": "acoes",     "label": "Ações",          "field": "id"},
            ]
            rows = [
                {
                    "id":              a["id"],
                    "processo_numero": a.get("processo_numero") or "—",
                    "tipo":            a["tipo"],
                    "data_hora":       a["data_hora"][:16].replace("T", " "),
                    "local":           a["local"],
                    "status":          a["status"],
                }
                for a in dados
            ]
            table = ui.table(columns=columns, rows=rows, row_key="id").style(
                "width:100%;background:white;border-radius:10px;"
                "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
            ).props("flat bordered")

            table.add_slot("body-cell-acoes", """
                <q-td :props="props">
                    <q-btn flat dense icon="delete" color="negative"
                           @click="$parent.$emit('delete', props.row)" />
                </q-td>
            """)

            async def del_aud(e):
                ok = await api_delete(f"/audiencias/{e.args['id']}")
                if ok:
                    notify_ok("Audiência removida!")
                    await carregar_audiencias()
                else:
                    notify_err("Erro ao remover")

            table.on("delete", del_aud)

    await carregar_audiencias()


# ─── ABA RELATÓRIO ───────────────────────────────────────────────────────────

async def aba_relatorio():
    ui.element("div").classes("section-title").set_text("📊 Relatório Operacional")

    dados = await api_get("/relatorio/operacional")

    if not dados:
        ui.element("div").style("color:#888;text-align:center;padding:40px").set_text(
            "Não foi possível carregar o relatório. Verifique a conexão com a API."
        )
        return

    # ─── Cards de resumo ──────────────────────────────────────────────────
    with ui.grid(columns=3).style("gap:16px;margin-bottom:28px"):
        stat_card("Total de Processos",  str(dados["total_processos"]),  BLUE)
        stat_card("Processos Ativos",    str(dados["processos_ativos"]), GREEN)
        stat_card("Processos Encerrados",str(dados["processos_encerrados"]), RED)
        stat_card("Total de Clientes",   str(dados["total_clientes"]),   BLUE_DK)
        stat_card("Total de Audiências", str(dados["total_audiencias"]), "#7B1FA2")
        stat_card("Audiências Próximas (30d)", str(dados["audiencias_proximas"]), "#E65100")

    with ui.grid(columns=2).style("gap:24px"):
        # ─── Processos por status ──────────────────────────────────────
        with ui.card().style(
            "background:white;border-radius:10px;padding:20px;"
            "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
        ):
            ui.element("div").style(
                f"font-size:14px;font-weight:600;color:{BLUE_DK};margin-bottom:12px"
            ).set_text("Processos por Status")
            por_status = dados.get("processos_por_status", {})
            cores_status = {
                "Ativo": GREEN, "Encerrado": RED, "Suspenso": "#F57F17", "Aguardando": BLUE
            }
            for s, qtd in por_status.items():
                total = max(sum(por_status.values()), 1)
                pct = int(qtd / total * 100)
                cor = cores_status.get(s, BLUE)
                with ui.element("div").style("margin-bottom:12px"):
                    with ui.row().style("justify-content:space-between;margin-bottom:4px"):
                        ui.element("span").style("font-size:13px;color:#444").set_text(s)
                        ui.element("span").style(
                            f"font-size:13px;font-weight:600;color:{cor}"
                        ).set_text(f"{qtd} ({pct}%)")
                    with ui.element("div").style(
                        "height:8px;background:#E3E8EF;border-radius:4px;overflow:hidden"
                    ):
                        ui.element("div").style(
                            f"height:100%;width:{pct}%;background:{cor};"
                            "border-radius:4px;transition:width 0.5s"
                        )

        # ─── Audiências por tipo ───────────────────────────────────────
        with ui.card().style(
            "background:white;border-radius:10px;padding:20px;"
            "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
        ):
            ui.element("div").style(
                f"font-size:14px;font-weight:600;color:{BLUE_DK};margin-bottom:12px"
            ).set_text("Audiências por Tipo")
            por_tipo = dados.get("audiencias_por_tipo", {})
            if por_tipo:
                for t, qtd in por_tipo.items():
                    total = max(sum(por_tipo.values()), 1)
                    pct = int(qtd / total * 100)
                    with ui.element("div").style("margin-bottom:12px"):
                        with ui.row().style("justify-content:space-between;margin-bottom:4px"):
                            ui.element("span").style("font-size:13px;color:#444").set_text(t)
                            ui.element("span").style(
                                f"font-size:13px;font-weight:600;color:{BLUE}"
                            ).set_text(f"{qtd} ({pct}%)")
                        with ui.element("div").style(
                            "height:8px;background:#E3E8EF;border-radius:4px;overflow:hidden"
                        ):
                            ui.element("div").style(
                                f"height:100%;width:{pct}%;background:{BLUE};"
                                "border-radius:4px;transition:width 0.5s"
                            )
            else:
                ui.element("div").style("color:#888;font-size:13px").set_text(
                    "Nenhuma audiência registrada."
                )

    # ─── Tabelas de recentes ───────────────────────────────────────────
    with ui.grid(columns=2).style("gap:24px;margin-top:24px"):
        # Processos recentes
        with ui.card().style(
            "background:white;border-radius:10px;padding:20px;"
            "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
        ):
            ui.element("div").style(
                f"font-size:14px;font-weight:600;color:{BLUE_DK};margin-bottom:12px"
            ).set_text("Últimos Processos Cadastrados")
            recentes = dados.get("processos_recentes", [])
            if recentes:
                cols = [
                    {"name": "numero",   "label": "Número",  "field": "numero"},
                    {"name": "tipo",     "label": "Tipo",    "field": "tipo_acao"},
                    {"name": "status",   "label": "Status",  "field": "status"},
                ]
                ui.table(columns=cols, rows=recentes, row_key="id").props("flat dense bordered").style(
                    "width:100%;font-size:12px"
                )
            else:
                ui.element("div").style("color:#888;font-size:13px").set_text("Nenhum processo ainda.")

        # Próximas audiências
        with ui.card().style(
            "background:white;border-radius:10px;padding:20px;"
            "box-shadow:0 1px 4px rgba(0,0,0,0.08)"
        ):
            ui.element("div").style(
                f"font-size:14px;font-weight:600;color:{BLUE_DK};margin-bottom:12px"
            ).set_text("Próximas Audiências (30 dias)")
            prox = dados.get("audiencias_proximas_lista", [])
            if prox:
                cols = [
                    {"name": "tipo",     "label": "Tipo",   "field": "tipo"},
                    {"name": "data",     "label": "Data",   "field": "data_hora"},
                    {"name": "local",    "label": "Local",  "field": "local"},
                ]
                rows_p = [
                    {**a, "data_hora": a["data_hora"][:16].replace("T", " ")} for a in prox
                ]
                ui.table(columns=cols, rows=rows_p, row_key="id").props("flat dense bordered").style(
                    "width:100%;font-size:12px"
                )
            else:
                ui.element("div").style("color:#888;font-size:13px").set_text(
                    "Nenhuma audiência nos próximos 30 dias."
                )

    # ─── Botão exportar (demonstrativo) ──────────────────────────────────
    with ui.row().style("justify-content:flex-end;margin-top:20px"):
        ui.button("📥 Exportar Relatório (CSV)", icon="download").style(
            f"background:{BLUE_DK};color:white;border-radius:8px"
        ).props("unelevated").on(
            "click",
            lambda: notify_ok("Funcionalidade de exportação: integre com pandas + csv.writer no endpoint /api/relatorio/exportar")
        )


# ════════════════════════════════════════════════════════════════════════════
# INICIALIZAÇÃO
# ════════════════════════════════════════════════════════════════════════════

if __name__ in {"__main__", "__mp_main__"}:
    # antigravity: easter egg Python clássico, importado conforme requisito
    try:
        import antigravity  # noqa: F401 — abre https://xkcd.com/353/ no browser do dev
    except Exception:
        pass

    ui.run(
        title="Escritório Modelo",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8080)),
        favicon="⚖",
        dark=False,
        reload=False,
    )
