import reflex as rx

config = rx.Config(app_name="desenvolvimento_portal_nexus_360", plugins=[rx.plugins.TailwindV3Plugin()])
