import reflex as rx
from desenvolvimento_portal_nexus_360.components.auth_ui import auth_container
from desenvolvimento_portal_nexus_360.components.layout import sidebar, topbar
from desenvolvimento_portal_nexus_360.components.dashboard import dashboard_view
from desenvolvimento_portal_nexus_360.components.projects import projects_view
from desenvolvimento_portal_nexus_360.components.reports import reports_view
from desenvolvimento_portal_nexus_360.components.files import files_view
from desenvolvimento_portal_nexus_360.components.products import products_view
from desenvolvimento_portal_nexus_360.components.settings import settings_view
from desenvolvimento_portal_nexus_360.states.auth_state import AuthState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.states.nav_state import NavState


def main_content() -> rx.Component:
    return rx.match(
        NavState.active_tab,
        ("Dashboard", dashboard_view()),
        ("Projetos", projects_view()),
        ("Relatórios", reports_view()),
        ("Arquivos", files_view()),
        ("Produtos", products_view()),
        ("Configurações", settings_view()),
        dashboard_view(),
    )


def main_app() -> rx.Component:
    return rx.el.div(
        sidebar(),
        rx.el.div(
            topbar(),
            rx.el.main(main_content(), class_name="flex-1 p-8 overflow-auto"),
            class_name="flex-1 flex flex-col min-w-0",
        ),
        class_name=rx.cond(
            ThemeState.is_dark,
            "flex h-screen w-full bg-[#0B1120] transition-colors duration-300 font-['Inter']",
            "flex h-screen w-full bg-gray-50 transition-colors duration-300 font-['Inter']",
        ),
    )


def index() -> rx.Component:
    return rx.cond(AuthState.is_logged_in, main_app(), auth_container())


app = rx.App(
    theme=rx.theme(appearance="light"),
    head_components=[
        rx.el.link(rel="preconnect", href="https://fonts.googleapis.com"),
        rx.el.link(
            rel="preconnect", href="https://fonts.gstatic.com", cross_origin=""
        ),
        rx.el.link(
            href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",
            rel="stylesheet",
        ),
    ],
)
app.add_page(index, route="/")