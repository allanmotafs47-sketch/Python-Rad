import reflex as rx
from desenvolvimento_portal_nexus_360.states.data_state import DataState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.components.shared import empty_state


def report_modal() -> rx.Component:
    return rx.cond(
        DataState.show_report_modal,
        rx.el.div(
            rx.el.div(
                rx.el.div(
                    rx.el.h2(
                        rx.cond(
                            DataState.is_editing_report,
                            "Editar Relatório",
                            "Novo Relatório",
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-xl font-bold text-white",
                            "text-xl font-bold text-gray-900",
                        ),
                    ),
                    rx.el.button(
                        rx.icon("x", class_name="w-5 h-5"),
                        on_click=DataState.close_report_modal,
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-slate-400 hover:text-white",
                            "text-gray-500 hover:text-gray-900",
                        ),
                    ),
                    class_name="flex items-center justify-between mb-6",
                ),
                rx.el.form(
                    rx.el.div(
                        rx.el.div(
                            rx.el.label(
                                "Título do Relatório",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="title",
                                default_value=DataState.current_report["title"],
                                key=DataState.current_report["id"] + "_title",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Data de Referência",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="date",
                                type="date",
                                default_value=DataState.current_report["date"],
                                key=DataState.current_report["id"] + "_date",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        class_name="grid grid-cols-2 gap-4",
                    ),
                    rx.el.div(
                        rx.el.label(
                            "Métricas Operacionais",
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "block text-sm font-medium text-slate-300 mb-1",
                                "block text-sm font-medium text-gray-700 mb-1",
                            ),
                        ),
                        rx.el.textarea(
                            name="metrics",
                            default_value=DataState.current_report["metrics"],
                            key=DataState.current_report["id"] + "_metrics",
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white h-24",
                                "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 h-24",
                            ),
                        ),
                        class_name="mb-6",
                    ),
                    rx.el.div(
                        rx.el.button(
                            "Cancelar",
                            type="button",
                            on_click=DataState.close_report_modal,
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "px-4 py-2 border border-slate-700 rounded-lg text-white hover:bg-slate-800",
                                "px-4 py-2 border border-gray-300 rounded-lg text-gray-900 hover:bg-gray-100",
                            ),
                        ),
                        rx.el.button(
                            "Salvar",
                            type="submit",
                            class_name="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg",
                        ),
                        class_name="flex justify-end gap-3",
                    ),
                    on_submit=DataState.save_report,
                    reset_on_submit=True,
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "bg-[#1E293B] border border-slate-800 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                    "bg-white border border-gray-200 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                ),
            ),
            class_name="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4",
        ),
        rx.fragment(),
    )


def report_row(report: dict) -> rx.Component:
    return rx.el.tr(
        rx.el.td(
            report["title"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm font-medium text-white border-b border-slate-800",
                "px-6 py-4 text-sm font-medium text-gray-900 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            report["date"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-slate-300 border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-600 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            report["metrics"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-slate-300 border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-600 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            rx.el.div(
                rx.el.button(
                    rx.icon("copy", class_name="w-4 h-4"),
                    on_click=lambda: DataState.open_edit_report(report["id"]),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-emerald-400 hover:text-emerald-300 p-1",
                        "text-emerald-600 hover:text-emerald-500 p-1",
                    ),
                ),
                rx.el.button(
                    rx.icon("trash-2", class_name="w-4 h-4"),
                    on_click=lambda: DataState.delete_report(report["id"]),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-red-400 hover:text-red-300 p-1",
                        "text-red-600 hover:text-red-500 p-1",
                    ),
                ),
                class_name="flex items-center gap-2",
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        class_name=rx.cond(
            ThemeState.is_dark, "hover:bg-slate-800/50", "hover:bg-gray-50"
        ),
    )


def reports_view() -> rx.Component:
    return rx.el.div(
        report_modal(),
        rx.el.div(
            rx.el.h1(
                "Relatório Operacional",
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "text-2xl font-bold text-white",
                    "text-2xl font-bold text-gray-900",
                ),
            ),
            rx.el.button(
                rx.icon("plus", class_name="w-4 h-4 mr-2"),
                "Novo Relatório",
                on_click=DataState.open_new_report,
                class_name="flex items-center bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-medium transition-colors",
            ),
            class_name="flex items-center justify-between mb-6",
        ),
        rx.cond(
            DataState.reports.length() == 0,
            empty_state(
                "file-bar-chart",
                "Nenhum relatório",
                "Não há dados para exibir. Crie um novo relatório.",
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.table(
                        rx.el.thead(
                            rx.el.tr(
                                rx.el.th(
                                    "Título",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Data",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Métricas",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Ações",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                            ),
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "bg-slate-800/50",
                                "bg-gray-50",
                            ),
                        ),
                        rx.el.tbody(rx.foreach(DataState.reports, report_row)),
                        class_name="w-full table-auto border-collapse",
                    ),
                    class_name="overflow-x-auto",
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "bg-[#1E293B] border border-slate-800 rounded-2xl overflow-hidden shadow-sm",
                    "bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm",
                ),
            ),
        ),
    )