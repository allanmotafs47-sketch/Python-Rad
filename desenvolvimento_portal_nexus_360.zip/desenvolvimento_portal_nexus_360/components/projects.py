import reflex as rx
from desenvolvimento_portal_nexus_360.states.data_state import DataState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.components.shared import empty_state


def project_modal() -> rx.Component:
    return rx.cond(
        DataState.show_project_modal,
        rx.el.div(
            rx.el.div(
                rx.el.div(
                    rx.el.h2(
                        rx.cond(
                            DataState.is_editing_project,
                            "Editar Projeto",
                            "Novo Projeto",
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-xl font-bold text-white",
                            "text-xl font-bold text-gray-900",
                        ),
                    ),
                    rx.el.button(
                        rx.icon("x", class_name="w-5 h-5"),
                        on_click=DataState.close_project_modal,
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-slate-400 hover:text-white",
                            "text-gray-500 hover:text-gray-900",
                        ),
                    ),
                    class_name="flex items-center justify-between mb-6",
                ),
                rx.el.form(
                    rx.el.div(
                        rx.el.div(
                            rx.el.label(
                                "Nome do Projeto",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="name",
                                default_value=DataState.current_project["name"],
                                key=DataState.current_project["id"],
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Status",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.div(
                                rx.el.select(
                                    rx.el.option(
                                        "Em Andamento", value="Em Andamento"
                                    ),
                                    rx.el.option(
                                        "Concluído", value="Concluído"
                                    ),
                                    rx.el.option("Pausado", value="Pausado"),
                                    name="status",
                                    default_value=DataState.current_project[
                                        "status"
                                    ],
                                    key=DataState.current_project["id"]
                                    + "_status",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "appearance-none w-full px-4 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                        "appearance-none w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                    ),
                                ),
                                rx.icon(
                                    "chevron-down",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "absolute right-3 top-3 w-4 h-4 text-slate-400 pointer-events-none",
                                        "absolute right-3 top-3 w-4 h-4 text-gray-500 pointer-events-none",
                                    ),
                                ),
                                class_name="relative",
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Responsável",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="owner",
                                default_value=DataState.current_project[
                                    "owner"
                                ],
                                key=DataState.current_project["id"] + "_owner",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Prioridade",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.div(
                                rx.el.select(
                                    rx.el.option("Baixa", value="Baixa"),
                                    rx.el.option("Média", value="Média"),
                                    rx.el.option("Alta", value="Alta"),
                                    name="priority",
                                    default_value=DataState.current_project[
                                        "priority"
                                    ],
                                    key=DataState.current_project["id"]
                                    + "_priority",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "appearance-none w-full px-4 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                        "appearance-none w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                    ),
                                ),
                                rx.icon(
                                    "chevron-down",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "absolute right-3 top-3 w-4 h-4 text-slate-400 pointer-events-none",
                                        "absolute right-3 top-3 w-4 h-4 text-gray-500 pointer-events-none",
                                    ),
                                ),
                                class_name="relative",
                            ),
                            class_name="mb-4",
                        ),
                        class_name="grid grid-cols-2 gap-4",
                    ),
                    rx.el.div(
                        rx.el.label(
                            "Observações",
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "block text-sm font-medium text-slate-300 mb-1",
                                "block text-sm font-medium text-gray-700 mb-1",
                            ),
                        ),
                        rx.el.textarea(
                            name="notes",
                            default_value=DataState.current_project["notes"],
                            key=DataState.current_project["id"] + "_notes",
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white h-24",
                                "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 h-24",
                            ),
                        ),
                        class_name="mb-6",
                    ),
                    rx.el.div(
                        rx.el.button(
                            "Cancelar",
                            type="button",
                            on_click=DataState.close_project_modal,
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "px-4 py-2 border border-slate-700 rounded-lg text-white hover:bg-slate-800",
                                "px-4 py-2 border border-gray-300 rounded-lg text-gray-900 hover:bg-gray-100",
                            ),
                        ),
                        rx.el.button(
                            "Salvar",
                            type="submit",
                            class_name="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg",
                        ),
                        class_name="flex justify-end gap-3",
                    ),
                    on_submit=DataState.save_project,
                    reset_on_submit=True,
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "bg-[#1E293B] border border-slate-800 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                    "bg-white border border-gray-200 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                ),
            ),
            class_name="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4",
        ),
        rx.fragment(),
    )


def project_row(project: dict) -> rx.Component:
    return rx.el.tr(
        rx.el.td(
            project["name"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-white border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-900 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            rx.el.span(
                project["status"],
                class_name=rx.cond(
                    project["status"] == "Concluído",
                    rx.cond(
                        ThemeState.is_dark,
                        "px-2 py-1 bg-emerald-500/10 text-emerald-400 rounded-md text-xs font-medium w-fit",
                        "px-2 py-1 bg-emerald-100 text-emerald-700 rounded-md text-xs font-medium w-fit",
                    ),
                    rx.cond(
                        ThemeState.is_dark,
                        "px-2 py-1 bg-cyan-500/10 text-cyan-400 rounded-md text-xs font-medium w-fit",
                        "px-2 py-1 bg-cyan-100 text-cyan-700 rounded-md text-xs font-medium w-fit",
                    ),
                ),
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            project["owner"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-slate-300 border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-600 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            project["priority"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-slate-300 border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-600 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            rx.el.div(
                rx.el.button(
                    rx.icon("copy", class_name="w-4 h-4"),
                    on_click=lambda: DataState.open_edit_project(project["id"]),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-cyan-400 hover:text-cyan-300 p-1",
                        "text-cyan-600 hover:text-cyan-500 p-1",
                    ),
                ),
                rx.el.button(
                    rx.icon("trash-2", class_name="w-4 h-4"),
                    on_click=lambda: DataState.delete_project(project["id"]),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-red-400 hover:text-red-300 p-1",
                        "text-red-600 hover:text-red-500 p-1",
                    ),
                ),
                class_name="flex items-center gap-2",
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        class_name=rx.cond(
            ThemeState.is_dark, "hover:bg-slate-800/50", "hover:bg-gray-50"
        ),
    )


def projects_view() -> rx.Component:
    return rx.el.div(
        project_modal(),
        rx.el.div(
            rx.el.h1(
                "Gestão de Projetos",
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "text-2xl font-bold text-white",
                    "text-2xl font-bold text-gray-900",
                ),
            ),
            rx.el.button(
                rx.icon("plus", class_name="w-4 h-4 mr-2"),
                "Novo Projeto",
                on_click=DataState.open_new_project,
                class_name="flex items-center bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg font-medium transition-colors",
            ),
            class_name="flex items-center justify-between mb-6",
        ),
        rx.cond(
            DataState.projects.length() == 0,
            empty_state(
                "folder-open",
                "Nenhum projeto",
                "Comece criando seu primeiro projeto no sistema.",
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.table(
                        rx.el.thead(
                            rx.el.tr(
                                rx.el.th(
                                    "Projeto",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Status",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Responsável",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Prioridade",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Ações",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                            ),
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "bg-slate-800/50",
                                "bg-gray-50",
                            ),
                        ),
                        rx.el.tbody(
                            rx.foreach(DataState.projects, project_row)
                        ),
                        class_name="w-full table-auto border-collapse",
                    ),
                    class_name="overflow-x-auto",
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "bg-[#1E293B] border border-slate-800 rounded-2xl overflow-hidden shadow-sm",
                    "bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm",
                ),
            ),
        ),
    )