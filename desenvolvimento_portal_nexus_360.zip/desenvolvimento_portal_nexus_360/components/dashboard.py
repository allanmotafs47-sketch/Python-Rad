import reflex as rx
from desenvolvimento_portal_nexus_360.states.data_state import DataState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState


def indicator_card(
    title: str, value: str, icon: str, color_class: str
) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.p(
                    title,
                    class_name=f"text-sm font-medium {ThemeState.text_muted} mb-1",
                ),
                rx.el.h3(
                    value,
                    class_name=f"text-3xl font-bold {ThemeState.text_main}",
                ),
                class_name="flex-1",
            ),
            rx.el.div(
                rx.icon(icon, class_name=f"w-6 h-6 {color_class}"),
                class_name=f"w-12 h-12 rounded-xl flex items-center justify-center bg-{color_class.split('-')[1]}-500/10",
            ),
            class_name="flex items-start justify-between",
        ),
        class_name=f"p-6 rounded-2xl {ThemeState.bg_card} border {ThemeState.border_color} shadow-sm hover:shadow-md transition-shadow",
    )


def dashboard_view() -> rx.Component:
    return rx.el.div(
        rx.el.h1(
            "Visão Geral",
            class_name=f"text-2xl font-bold mb-6 {ThemeState.text_main}",
        ),
        rx.el.div(
            indicator_card(
                "Projetos Ativos",
                DataState.total_projects,
                "folder-kanban",
                "text-cyan-500",
            ),
            indicator_card(
                "Relatórios",
                DataState.total_reports,
                "file-text",
                "text-emerald-500",
            ),
            indicator_card(
                "Arquivos", DataState.total_files, "files", "text-purple-500"
            ),
            indicator_card(
                "Produtos",
                DataState.total_products,
                "package",
                "text-amber-500",
            ),
            class_name="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8",
        ),
        rx.el.div(
            rx.el.h2(
                "Atividade Recente",
                class_name=f"text-xl font-semibold mb-4 {ThemeState.text_main}",
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.p(
                        "Sistema inicializado e componentes base carregados.",
                        class_name=ThemeState.text_muted,
                    ),
                    class_name=f"p-6 rounded-2xl {ThemeState.bg_card} border {ThemeState.border_color}",
                ),
            ),
            class_name="mt-8",
        ),
        class_name="w-full",
    )