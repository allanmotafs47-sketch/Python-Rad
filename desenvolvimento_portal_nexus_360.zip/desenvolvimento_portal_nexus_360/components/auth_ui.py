import reflex as rx
from desenvolvimento_portal_nexus_360.states.auth_state import AuthState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.states.settings_state import SettingsState


def auth_container() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.icon(
                    "hexagon", class_name="w-12 h-12 text-cyan-500 mb-4 mx-auto"
                ),
                rx.el.h2(
                    SettingsState.brand_name,
                    class_name=f"text-3xl font-bold text-center mb-2 {ThemeState.text_main}",
                ),
                rx.el.p(
                    "Portal Institucional",
                    class_name=f"text-center mb-8 {ThemeState.text_muted}",
                ),
                rx.cond(
                    AuthState.error_message != "",
                    rx.el.div(
                        AuthState.error_message,
                        class_name="bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-lg text-sm mb-4 text-center",
                    ),
                ),
                # ✅ Exibe mensagem de sucesso na redefinição
                rx.cond(
                    AuthState.recovery_success,
                    rx.el.div(
                        "Senha redefinida com sucesso! Faça login.",
                        class_name="bg-emerald-500/10 border border-emerald-500/50 text-emerald-500 p-3 rounded-lg text-sm mb-4 text-center",
                    ),
                ),
                # ✅ Três telas: recuperação, cadastro ou login
                rx.cond(
                    AuthState.is_recovering,
                    recovery_form(),
                    rx.cond(
                        AuthState.is_registering,
                        register_form(),
                        login_form(),
                    ),
                ),
                class_name=f"{ThemeState.bg_card} p-8 rounded-2xl shadow-xl w-full max-w-md border {ThemeState.border_color}",
            ),
            class_name="flex flex-col items-center justify-center min-h-screen w-full p-4",
        ),
        class_name=f"min-h-screen w-full {ThemeState.bg_app} transition-colors duration-300",
    )


def login_form() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.label(
                "E-mail",
                class_name=f"block text-sm font-medium mb-1 {ThemeState.text_muted}",
            ),
            rx.el.input(
                type="email",
                on_change=AuthState.set_login_email.debounce(300),
                class_name=f"w-full px-4 py-2 rounded-lg bg-transparent border {ThemeState.border_color} {ThemeState.text_main} focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all",
            ),
            class_name="mb-4",
        ),
        rx.el.div(
            rx.el.label(
                "Senha",
                class_name=f"block text-sm font-medium mb-1 {ThemeState.text_muted}",
            ),
            rx.el.input(
                type="password",
                on_change=AuthState.set_login_password.debounce(300),
                class_name=f"w-full px-4 py-2 rounded-lg bg-transparent border {ThemeState.border_color} {ThemeState.text_main} focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all",
            ),
            class_name="mb-2",
        ),
        # ✅ Link "Esqueci minha senha"
        rx.el.div(
            rx.el.span(
                "Esqueci minha senha",
                on_click=AuthState.show_recovery,
                class_name=f"text-sm text-cyan-500 hover:text-cyan-400 cursor-pointer",
            ),
            class_name="text-right mb-6",
        ),
        rx.el.button(
            "Entrar",
            on_click=AuthState.login,
            class_name="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-lg shadow-cyan-500/30",
        ),
        rx.el.p(
            "Não possui conta? ",
            rx.el.span(
                "Cadastre-se",
                on_click=AuthState.toggle_mode,
                class_name="text-cyan-500 hover:text-cyan-400 cursor-pointer font-medium",
            ),
            class_name=f"text-center mt-6 text-sm {ThemeState.text_muted}",
        ),
    )


# ✅ Nova tela de recuperação de senha
def recovery_form() -> rx.Component:
    return rx.el.div(
        rx.el.h3(
            "Redefinir Senha",
            class_name=f"text-xl font-bold mb-6 text-center {ThemeState.text_main}",
        ),
        rx.el.div(
            rx.el.label(
                "E-mail cadastrado",
                class_name=f"block text-sm font-medium mb-1 {ThemeState.text_muted}",
            ),
            rx.el.input(
                type="email",
                on_change=AuthState.set_recovery_email.debounce(300),
                class_name=f"w-full px-4 py-2 rounded-lg bg-transparent border {ThemeState.border_color} {ThemeState.text_main} focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all",
            ),
            class_name="mb-4",
        ),
        rx.el.div(
            rx.el.label(
                "Nova senha",
                class_name=f"block text-sm font-medium mb-1 {ThemeState.text_muted}",
            ),
            rx.el.input(
                type="password",
                on_change=AuthState.set_recovery_new_password.debounce(300),
                class_name=f"w-full px-4 py-2 rounded-lg bg-transparent border {ThemeState.border_color} {ThemeState.text_main} focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all",
            ),
            class_name="mb-6",
        ),
        rx.el.button(
            "Redefinir Senha",
            on_click=AuthState.reset_password,
            class_name="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-lg shadow-cyan-500/30",
        ),
        rx.el.p(
            rx.el.span(
                "← Voltar ao login",
                on_click=AuthState.back_to_login,
                class_name="text-cyan-500 hover:text-cyan-400 cursor-pointer font-medium",
            ),
            class_name=f"text-center mt-6 text-sm {ThemeState.text_muted}",
        ),
    )


def register_form() -> rx.Component:
    # sem alterações — igual ao original
    ...