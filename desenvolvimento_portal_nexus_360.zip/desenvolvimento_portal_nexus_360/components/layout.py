import reflex as rx
from desenvolvimento_portal_nexus_360.states.auth_state import AuthState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.states.nav_state import NavState
from desenvolvimento_portal_nexus_360.states.settings_state import SettingsState


def sidebar() -> rx.Component:
    nav_items = [
        {"icon": "layout-dashboard", "label": "Dashboard"},
        {"icon": "folder-kanban", "label": "Projetos"},
        {"icon": "file-text", "label": "Relatórios"},
        {"icon": "files", "label": "Arquivos"},
        {"icon": "package", "label": "Produtos"},
        {"icon": "settings", "label": "Configurações"},
    ]

    return rx.el.aside(
        rx.el.div(
            rx.el.div(
                rx.icon("hexagon", class_name="w-8 h-8 text-cyan-500"),
                rx.el.span(
                    SettingsState.brand_name,
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-xl font-bold text-white",
                        "text-xl font-bold text-gray-900",
                    ),
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "flex h-16 items-center gap-3 border-b border-slate-800 px-6",
                    "flex h-16 items-center gap-3 border-b border-gray-200 px-6",
                ),
            ),
            rx.el.nav(
                rx.foreach(
                    nav_items,
                    lambda item: rx.el.a(
                        rx.icon(
                            item["icon"],
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "w-5 h-5 text-slate-400",
                                "w-5 h-5 text-gray-500",
                            ),
                        ),
                        rx.el.span(
                            item["label"],
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "font-medium text-white",
                                "font-medium text-gray-900",
                            ),
                        ),
                        on_click=NavState.set_tab(item["label"]),
                        class_name=rx.cond(
                            NavState.active_tab == item["label"],
                            "flex items-center gap-3 px-6 py-3 bg-cyan-500/20 border-r-4 border-cyan-500 transition-all cursor-pointer",
                            "flex items-center gap-3 px-6 py-3 hover:bg-cyan-500/10 hover:border-r-4 border-cyan-500 transition-all cursor-pointer",
                        ),
                    ),
                ),
                class_name="flex w-full flex-col py-4",
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "flex flex-col min-h-0 bg-[#1E293B] border-r border-slate-800 w-64 h-screen shrink-0",
                "flex flex-col min-h-0 bg-white border-r border-gray-200 w-64 h-screen shrink-0",
            ),
        )
    )


def topbar() -> rx.Component:
    return rx.el.header(
        rx.el.div(
            rx.el.div(
                "Bem-vindo(a) ao portal",
                class_name=rx.cond(
                    ThemeState.is_dark, "text-slate-400", "text-gray-500"
                ),
            ),
            rx.el.div(
                rx.el.button(
                    rx.cond(
                        ThemeState.is_dark,
                        rx.icon("sun", class_name="w-5 h-5 text-amber-400"),
                        rx.icon("moon", class_name="w-5 h-5 text-slate-600"),
                    ),
                    on_click=ThemeState.toggle_theme,
                    class_name="p-2 rounded-full hover:bg-slate-500/20 transition-colors",
                ),
                rx.el.div(
                    rx.el.div(
                        AuthState.current_user["name"],
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-sm font-medium text-white",
                            "text-sm font-medium text-gray-900",
                        ),
                    ),
                    rx.image(
                        src=f"https://api.dicebear.com/9.x/initials/svg?seed={AuthState.current_user['name']}",
                        class_name="w-8 h-8 rounded-full",
                    ),
                    class_name="flex items-center gap-3",
                ),
                rx.el.button(
                    rx.icon("log-out", class_name="w-5 h-5"),
                    on_click=AuthState.logout,
                    class_name="text-red-500 hover:bg-red-500/10 p-2 rounded-full transition-colors ml-2",
                ),
                class_name="flex items-center gap-4",
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "flex items-center justify-between h-16 px-8 bg-[#1E293B] border-b border-slate-800 shadow-sm",
                "flex items-center justify-between h-16 px-8 bg-white border-b border-gray-200 shadow-sm",
            ),
        )
    )