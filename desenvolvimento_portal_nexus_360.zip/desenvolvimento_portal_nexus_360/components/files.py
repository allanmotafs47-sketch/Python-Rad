import reflex as rx
from desenvolvimento_portal_nexus_360.states.data_state import DataState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.states.file_upload_state import FileUploadState
from desenvolvimento_portal_nexus_360.components.shared import empty_state


UPLOAD_ID = "nexus_file_upload"


def file_row(file_item: dict) -> rx.Component:
    return rx.el.tr(
        rx.el.td(
            rx.el.div(
                rx.icon(
                    "file",
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "w-5 h-5 text-purple-400 mr-3",
                        "w-5 h-5 text-purple-500 mr-3",
                    ),
                ),
                rx.el.span(
                    file_item["filename"],
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-sm font-medium text-white",
                        "text-sm font-medium text-gray-900",
                    ),
                ),
                class_name="flex items-center",
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            file_item["size"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-slate-300 border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-600 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            file_item["description"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-slate-300 border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-600 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            rx.el.div(
                rx.el.button(
                    rx.icon("download", class_name="w-4 h-4"),
                    on_click=rx.download(
                        url=rx.get_upload_url(file_item["stored_name"]),
                        filename=file_item["filename"],
                    ),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-purple-400 hover:text-purple-300 p-1",
                        "text-purple-600 hover:text-purple-500 p-1",
                    ),
                ),
                rx.el.button(
                    rx.icon("trash-2", class_name="w-4 h-4"),
                    on_click=lambda: DataState.delete_file(file_item["id"]),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-red-400 hover:text-red-300 p-1",
                        "text-red-600 hover:text-red-500 p-1",
                    ),
                ),
                class_name="flex items-center gap-2",
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        class_name=rx.cond(
            ThemeState.is_dark, "hover:bg-slate-800/50", "hover:bg-gray-50"
        ),
    )


def files_view() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h1(
                "Gestão de Arquivos",
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "text-2xl font-bold text-white",
                    "text-2xl font-bold text-gray-900",
                ),
            ),
            class_name="flex items-center justify-between mb-6",
        ),
        rx.el.div(
            rx.upload.root(
                rx.el.div(
                    rx.icon(
                        tag="cloud_upload",
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "w-10 h-10 text-slate-500 mb-3",
                            "w-10 h-10 text-gray-400 mb-3",
                        ),
                    ),
                    rx.el.p(
                        "Arraste arquivos aqui ou clique para selecionar",
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-sm font-medium text-slate-300",
                            "text-sm font-medium text-gray-600",
                        ),
                    ),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "flex flex-col items-center justify-center p-8 border-2 border-dashed border-slate-700 hover:border-purple-500 rounded-2xl cursor-pointer bg-[#0B1120] transition-colors",
                        "flex flex-col items-center justify-center p-8 border-2 border-dashed border-gray-300 hover:border-purple-500 rounded-2xl cursor-pointer bg-gray-50 transition-colors",
                    ),
                ),
                id=UPLOAD_ID,
                multiple=True,
                on_drop=FileUploadState.handle_upload(
                    rx.upload_files(upload_id=UPLOAD_ID)
                ),
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "bg-[#1E293B] border border-slate-800 rounded-2xl p-6 mb-8 shadow-sm",
                "bg-white border border-gray-200 rounded-2xl p-6 mb-8 shadow-sm",
            ),
        ),
        rx.cond(
            DataState.files.length() == 0,
            empty_state(
                "files",
                "Nenhum arquivo",
                "Faça o upload de documentos para armazená-los.",
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.table(
                        rx.el.thead(
                            rx.el.tr(
                                rx.el.th(
                                    "Arquivo",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Tamanho",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Descrição",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                                rx.el.th(
                                    "Ações",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                        "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                    ),
                                ),
                            ),
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "bg-slate-800/50",
                                "bg-gray-50",
                            ),
                        ),
                        rx.el.tbody(rx.foreach(DataState.files, file_row)),
                        class_name="w-full table-auto border-collapse",
                    ),
                    class_name="overflow-x-auto",
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "bg-[#1E293B] border border-slate-800 rounded-2xl overflow-hidden shadow-sm",
                    "bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm",
                ),
            ),
        ),
    )