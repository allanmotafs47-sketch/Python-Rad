import reflex as rx
from desenvolvimento_portal_nexus_360.states.data_state import DataState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.components.shared import empty_state


def product_modal() -> rx.Component:
    return rx.cond(
        DataState.show_product_modal,
        rx.el.div(
            rx.el.div(
                rx.el.div(
                    rx.el.h2(
                        rx.cond(
                            DataState.is_editing_product,
                            "Editar Produto",
                            "Novo Produto",
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-xl font-bold text-white",
                            "text-xl font-bold text-gray-900",
                        ),
                    ),
                    rx.el.button(
                        rx.icon("x", class_name="w-5 h-5"),
                        on_click=DataState.close_product_modal,
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-slate-400 hover:text-white",
                            "text-gray-500 hover:text-gray-900",
                        ),
                    ),
                    class_name="flex items-center justify-between mb-6",
                ),
                rx.el.form(
                    rx.el.div(
                        rx.el.div(
                            rx.el.label(
                                "Nome do Produto",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="name",
                                default_value=DataState.current_product["name"],
                                key=DataState.current_product["id"] + "_name",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Preço (R$)",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="price",
                                type="number",
                                step="0.01",
                                default_value=DataState.current_product[
                                    "price"
                                ].to(str),
                                key=DataState.current_product["id"] + "_price",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Categoria",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.div(
                                rx.el.select(
                                    rx.el.option("Software", value="Software"),
                                    rx.el.option("Hardware", value="Hardware"),
                                    rx.el.option("Serviço", value="Serviço"),
                                    name="category",
                                    default_value=DataState.current_product[
                                        "category"
                                    ],
                                    key=DataState.current_product["id"]
                                    + "_cat",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "appearance-none w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                        "appearance-none w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                    ),
                                ),
                                rx.icon(
                                    "chevron-down",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "absolute right-3 top-3 w-4 h-4 text-slate-400 pointer-events-none",
                                        "absolute right-3 top-3 w-4 h-4 text-gray-500 pointer-events-none",
                                    ),
                                ),
                                class_name="relative",
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Status",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.div(
                                rx.el.select(
                                    rx.el.option("Ativo", value="Ativo"),
                                    rx.el.option("Inativo", value="Inativo"),
                                    name="status",
                                    default_value=DataState.current_product[
                                        "status"
                                    ],
                                    key=DataState.current_product["id"]
                                    + "_status",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "appearance-none w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                        "appearance-none w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                    ),
                                ),
                                rx.icon(
                                    "chevron-down",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "absolute right-3 top-3 w-4 h-4 text-slate-400 pointer-events-none",
                                        "absolute right-3 top-3 w-4 h-4 text-gray-500 pointer-events-none",
                                    ),
                                ),
                                class_name="relative",
                            ),
                            class_name="mb-4",
                        ),
                        class_name="grid grid-cols-2 gap-4",
                    ),
                    rx.el.div(
                        rx.el.label(
                            "Descrição",
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "block text-sm font-medium text-slate-300 mb-1",
                                "block text-sm font-medium text-gray-700 mb-1",
                            ),
                        ),
                        rx.el.textarea(
                            name="description",
                            default_value=DataState.current_product[
                                "description"
                            ],
                            key=DataState.current_product["id"] + "_desc",
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white h-24",
                                "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 h-24",
                            ),
                        ),
                        class_name="mb-6",
                    ),
                    rx.el.div(
                        rx.el.button(
                            "Cancelar",
                            type="button",
                            on_click=DataState.close_product_modal,
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "px-4 py-2 border border-slate-700 rounded-lg text-white hover:bg-slate-800",
                                "px-4 py-2 border border-gray-300 rounded-lg text-gray-900 hover:bg-gray-100",
                            ),
                        ),
                        rx.el.button(
                            "Salvar",
                            type="submit",
                            class_name="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg",
                        ),
                        class_name="flex justify-end gap-3",
                    ),
                    on_submit=DataState.save_product,
                    reset_on_submit=True,
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "bg-[#1E293B] border border-slate-800 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                    "bg-white border border-gray-200 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                ),
            ),
            class_name="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4",
        ),
        rx.fragment(),
    )


def product_card(product: dict) -> rx.Component:
    return rx.el.div(
        rx.image(
            src=product["image_url"], class_name="w-full h-40 object-cover"
        ),
        rx.el.div(
            rx.el.div(
                rx.el.span(
                    product["category"],
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-xs font-medium text-amber-400 bg-amber-500/10 px-2 py-1 rounded-md",
                        "text-xs font-medium text-amber-700 bg-amber-100 px-2 py-1 rounded-md",
                    ),
                ),
                rx.el.span(
                    product["status"],
                    class_name=rx.cond(
                        product["status"] == "Ativo",
                        rx.cond(
                            ThemeState.is_dark,
                            "text-xs font-medium text-emerald-400",
                            "text-xs font-medium text-emerald-600",
                        ),
                        rx.cond(
                            ThemeState.is_dark,
                            "text-xs font-medium text-slate-400",
                            "text-xs font-medium text-gray-500",
                        ),
                    ),
                ),
                class_name="flex items-center justify-between mb-3",
            ),
            rx.el.h3(
                product["name"],
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "text-lg font-bold text-white mb-1 truncate",
                    "text-lg font-bold text-gray-900 mb-1 truncate",
                ),
            ),
            rx.el.p(
                product["description"],
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "text-sm text-slate-400 mb-4 line-clamp-2 h-10",
                    "text-sm text-gray-500 mb-4 line-clamp-2 h-10",
                ),
            ),
            rx.el.div(
                rx.el.span(
                    f"R$ {product['price']:.2f}",
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-xl font-bold text-white",
                        "text-xl font-bold text-gray-900",
                    ),
                ),
                rx.el.div(
                    rx.el.button(
                        rx.icon("copy", class_name="w-4 h-4"),
                        on_click=lambda: DataState.open_edit_product(
                            product["id"]
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-amber-400 hover:text-amber-300 p-2 bg-[#0B1120] rounded-lg",
                            "text-amber-600 hover:text-amber-500 p-2 bg-gray-50 rounded-lg",
                        ),
                    ),
                    rx.el.button(
                        rx.icon("trash-2", class_name="w-4 h-4"),
                        on_click=lambda: DataState.delete_product(
                            product["id"]
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-red-400 hover:text-red-300 p-2 bg-[#0B1120] rounded-lg",
                            "text-red-600 hover:text-red-500 p-2 bg-gray-50 rounded-lg",
                        ),
                    ),
                    class_name="flex items-center gap-2",
                ),
                class_name="flex items-center justify-between mt-auto",
            ),
            class_name="p-5 flex flex-col",
        ),
        class_name=rx.cond(
            ThemeState.is_dark,
            "bg-[#1E293B] border border-slate-800 rounded-2xl overflow-hidden shadow-sm flex flex-col",
            "bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm flex flex-col",
        ),
    )


def products_view() -> rx.Component:
    return rx.el.div(
        product_modal(),
        rx.el.div(
            rx.el.h1(
                "Catálogo de Produtos",
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "text-2xl font-bold text-white",
                    "text-2xl font-bold text-gray-900",
                ),
            ),
            rx.el.button(
                rx.icon("plus", class_name="w-4 h-4 mr-2"),
                "Novo Produto",
                on_click=DataState.open_new_product,
                class_name="flex items-center bg-amber-600 hover:bg-amber-500 text-white px-4 py-2 rounded-lg font-medium transition-colors",
            ),
            class_name="flex items-center justify-between mb-6",
        ),
        rx.cond(
            DataState.products.length() == 0,
            empty_state(
                "package-open",
                "Nenhum produto",
                "O catálogo de produtos está vazio. Adicione um novo.",
            ),
            rx.el.div(
                rx.foreach(DataState.products, product_card),
                class_name="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6",
            ),
        ),
    )