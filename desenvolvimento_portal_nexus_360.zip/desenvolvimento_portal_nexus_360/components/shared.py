import reflex as rx
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState


def empty_state(icon: str, title: str, description: str) -> rx.Component:
    return rx.el.div(
        rx.icon(
            icon,
            class_name=rx.cond(
                ThemeState.is_dark,
                "w-16 h-16 text-slate-700 mb-4",
                "w-16 h-16 text-gray-300 mb-4",
            ),
        ),
        rx.el.h3(
            title,
            class_name=rx.cond(
                ThemeState.is_dark,
                "text-lg font-medium text-white mb-2",
                "text-lg font-medium text-gray-900 mb-2",
            ),
        ),
        rx.el.p(
            description,
            class_name=rx.cond(
                ThemeState.is_dark,
                "text-sm text-slate-400 text-center max-w-md",
                "text-sm text-gray-500 text-center max-w-md",
            ),
        ),
        class_name=rx.cond(
            ThemeState.is_dark,
            "flex flex-col items-center justify-center py-16 px-4 w-full bg-[#1E293B] border border-slate-800 rounded-2xl shadow-sm",
            "flex flex-col items-center justify-center py-16 px-4 w-full bg-white border border-gray-200 rounded-2xl shadow-sm",
        ),
    )