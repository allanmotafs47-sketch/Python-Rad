import reflex as rx
from desenvolvimento_portal_nexus_360.states.settings_state import SettingsState
from desenvolvimento_portal_nexus_360.states.theme_state import ThemeState
from desenvolvimento_portal_nexus_360.components.shared import empty_state


def settings_view() -> rx.Component:
    return rx.el.div(
        rx.el.h1(
            "Configurações",
            class_name=rx.cond(
                ThemeState.is_dark,
                "text-2xl font-bold text-white mb-6",
                "text-2xl font-bold text-gray-900 mb-6",
            ),
        ),
        rx.el.div(
            rx.el.div(
                rx.foreach(
                    [
                        "Institucional",
                        "Usuários e Permissões",
                        "Implantação e Cloud",
                    ],
                    lambda tab: rx.el.button(
                        tab,
                        on_click=SettingsState.set_section(tab),
                        class_name=rx.cond(
                            SettingsState.active_section == tab,
                            rx.cond(
                                ThemeState.is_dark,
                                "px-4 py-2 font-medium text-sm text-white border-b-2 border-cyan-500 bg-slate-800/50",
                                "px-4 py-2 font-medium text-sm text-cyan-700 border-b-2 border-cyan-500 bg-cyan-50",
                            ),
                            rx.cond(
                                ThemeState.is_dark,
                                "px-4 py-2 font-medium text-sm text-slate-400 hover:text-white hover:bg-slate-800/50 border-b-2 border-transparent transition-colors",
                                "px-4 py-2 font-medium text-sm text-gray-500 hover:text-gray-900 hover:bg-gray-50 border-b-2 border-transparent transition-colors",
                            ),
                        ),
                    ),
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "flex border-b border-slate-800 mb-6",
                    "flex border-b border-gray-200 mb-6",
                ),
            ),
            rx.match(
                SettingsState.active_section,
                ("Institucional", institutional_section()),
                ("Usuários e Permissões", users_section()),
                ("Implantação e Cloud", deployment_section()),
                institutional_section(),
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "bg-[#1E293B] border border-slate-800 rounded-2xl p-6 shadow-sm",
                "bg-white border border-gray-200 rounded-2xl p-6 shadow-sm",
            ),
        ),
    )


def institutional_section() -> rx.Component:
    return rx.el.form(
        rx.el.h2(
            "Identidade Visual e Informações",
            class_name=rx.cond(
                ThemeState.is_dark,
                "text-lg font-semibold text-white mb-4",
                "text-lg font-semibold text-gray-900 mb-4",
            ),
        ),
        rx.el.div(
            rx.el.div(
                rx.el.label(
                    "Nome do Sistema",
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "block text-sm font-medium text-slate-300 mb-1",
                        "block text-sm font-medium text-gray-700 mb-1",
                    ),
                ),
                rx.el.input(
                    name="brand_name",
                    default_value=SettingsState.brand_name,
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white max-w-md",
                        "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900 max-w-md",
                    ),
                ),
                class_name="mb-4",
            ),
            rx.el.div(
                rx.el.label(
                    "Cor de Destaque",
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "block text-sm font-medium text-slate-300 mb-1",
                        "block text-sm font-medium text-gray-700 mb-1",
                    ),
                ),
                rx.el.div(
                    rx.el.select(
                        rx.el.option("Cyan", value="cyan"),
                        rx.el.option("Blue", value="blue"),
                        rx.el.option("Emerald", value="emerald"),
                        rx.el.option("Purple", value="purple"),
                        name="brand_color",
                        default_value="cyan",
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "appearance-none w-full px-4 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                            "appearance-none w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                        ),
                    ),
                    rx.icon(
                        "chevron-down",
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "absolute right-3 top-3 w-4 h-4 text-slate-400 pointer-events-none",
                            "absolute right-3 top-3 w-4 h-4 text-gray-500 pointer-events-none",
                        ),
                    ),
                    class_name="relative max-w-md",
                ),
                class_name="mb-4",
            ),
            class_name="mb-6",
        ),
        rx.el.div(
            rx.el.button(
                "Salvar Alterações",
                type="submit",
                class_name="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-medium transition-colors",
            ),
        ),
        on_submit=SettingsState.save_institutional,
    )


def deployment_section() -> rx.Component:
    return rx.el.div(
        rx.el.h2(
            "Implantação e Hospedagem Gratuita",
            class_name=rx.cond(
                ThemeState.is_dark,
                "text-lg font-semibold text-white mb-4",
                "text-lg font-semibold text-gray-900 mb-4",
            ),
        ),
        rx.el.p(
            "Siga os passos abaixo para publicar o código fonte em um repositório GitHub e hospedar o portal na Railway, sem custos ou necessidade de credenciais externas complexas.",
            class_name=rx.cond(
                ThemeState.is_dark,
                "text-slate-300 mb-6",
                "text-gray-600 mb-6",
            ),
        ),
        rx.el.div(
            rx.el.div(
                rx.el.h3(
                    "1. Publicação no GitHub",
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "font-semibold text-white mb-2",
                        "font-semibold text-gray-900 mb-2",
                    ),
                ),
                rx.el.ol(
                    rx.el.li("Crie uma conta gratuita em github.com."),
                    rx.el.li(
                        "Crie um novo repositório (pode ser público ou privado)."
                    ),
                    rx.el.li(
                        "Baixe o código gerado deste projeto para o seu computador."
                    ),
                    rx.el.li(
                        "Abra o terminal na pasta do projeto e execute os comandos:",
                        class_name="mb-2",
                    ),
                    rx.el.pre(
                        rx.el.code(
                            'git init\ngit add .\ngit commit -m "Initial commit"\ngit branch -M main\ngit remote add origin SEU_REPOSITORIO_URL\ngit push -u origin main',
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "text-sm text-cyan-400 font-mono",
                                "text-sm text-cyan-700 font-mono",
                            ),
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "bg-[#0B1120] p-3 rounded-lg border border-slate-700 overflow-x-auto",
                            "bg-gray-100 p-3 rounded-lg border border-gray-300 overflow-x-auto",
                        ),
                    ),
                    class_name="list-decimal pl-5 space-y-1 text-sm "
                    + rx.cond(
                        ThemeState.is_dark,
                        "text-slate-400",
                        "text-gray-600",
                    ),
                ),
                class_name="mb-6",
            ),
            rx.el.div(
                rx.el.h3(
                    "2. Hospedagem na Railway",
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "font-semibold text-white mb-2",
                        "font-semibold text-gray-900 mb-2",
                    ),
                ),
                rx.el.ol(
                    rx.el.li(
                        "Acesse railway.app e faça login com sua conta GitHub."
                    ),
                    rx.el.li(
                        "No painel, clique em 'New Project' > 'Deploy from GitHub repo'."
                    ),
                    rx.el.li(
                        "Selecione o repositório que você acabou de criar."
                    ),
                    rx.el.li(
                        "A Railway detectará automaticamente que é um projeto Python/Reflex e iniciará o build."
                    ),
                    rx.el.li(
                        "Após o deploy, vá em 'Settings' do serviço > 'Networking' e clique em 'Generate Domain' para obter um link público e gratuito.",
                        class_name="mb-2",
                    ),
                    class_name="list-decimal pl-5 space-y-1 text-sm "
                    + rx.cond(
                        ThemeState.is_dark,
                        "text-slate-400",
                        "text-gray-600",
                    ),
                ),
            ),
            class_name="space-y-6",
        ),
    )


def user_row(user: dict) -> rx.Component:
    return rx.el.tr(
        rx.el.td(
            user["name"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm font-medium text-white border-b border-slate-800",
                "px-6 py-4 text-sm font-medium text-gray-900 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            user["email"],
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 text-sm text-slate-300 border-b border-slate-800",
                "px-6 py-4 text-sm text-gray-600 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            rx.el.span(
                user["role"],
                class_name=rx.cond(
                    user["role"] == "Admin",
                    rx.cond(
                        ThemeState.is_dark,
                        "px-2 py-1 bg-purple-500/10 text-purple-400 rounded-md text-xs font-medium w-fit",
                        "px-2 py-1 bg-purple-100 text-purple-700 rounded-md text-xs font-medium w-fit",
                    ),
                    rx.cond(
                        ThemeState.is_dark,
                        "px-2 py-1 bg-slate-700 text-slate-300 rounded-md text-xs font-medium w-fit",
                        "px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs font-medium w-fit",
                    ),
                ),
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            rx.el.span(
                user["status"],
                class_name=rx.cond(
                    user["status"] == "Ativo",
                    rx.cond(
                        ThemeState.is_dark,
                        "px-2 py-1 bg-emerald-500/10 text-emerald-400 rounded-md text-xs font-medium w-fit",
                        "px-2 py-1 bg-emerald-100 text-emerald-700 rounded-md text-xs font-medium w-fit",
                    ),
                    rx.cond(
                        ThemeState.is_dark,
                        "px-2 py-1 bg-red-500/10 text-red-400 rounded-md text-xs font-medium w-fit",
                        "px-2 py-1 bg-red-100 text-red-700 rounded-md text-xs font-medium w-fit",
                    ),
                ),
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        rx.el.td(
            rx.el.div(
                rx.el.button(
                    rx.icon("copy", class_name="w-4 h-4"),
                    on_click=lambda: SettingsState.open_edit_user(user["id"]),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-cyan-400 hover:text-cyan-300 p-1",
                        "text-cyan-600 hover:text-cyan-500 p-1",
                    ),
                ),
                rx.el.button(
                    rx.icon("trash-2", class_name="w-4 h-4"),
                    on_click=lambda: SettingsState.delete_user(user["id"]),
                    class_name=rx.cond(
                        ThemeState.is_dark,
                        "text-red-400 hover:text-red-300 p-1",
                        "text-red-600 hover:text-red-500 p-1",
                    ),
                ),
                class_name="flex items-center gap-2",
            ),
            class_name=rx.cond(
                ThemeState.is_dark,
                "px-6 py-4 border-b border-slate-800",
                "px-6 py-4 border-b border-gray-200",
            ),
        ),
        class_name=rx.cond(
            ThemeState.is_dark, "hover:bg-slate-800/50", "hover:bg-gray-50"
        ),
    )


def user_modal() -> rx.Component:
    return rx.cond(
        SettingsState.show_user_modal,
        rx.el.div(
            rx.el.div(
                rx.el.div(
                    rx.el.h2(
                        rx.cond(
                            SettingsState.is_editing_user,
                            "Editar Usuário",
                            "Novo Usuário",
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-xl font-bold text-white",
                            "text-xl font-bold text-gray-900",
                        ),
                    ),
                    rx.el.button(
                        rx.icon("x", class_name="w-5 h-5"),
                        on_click=SettingsState.close_user_modal,
                        class_name=rx.cond(
                            ThemeState.is_dark,
                            "text-slate-400 hover:text-white",
                            "text-gray-500 hover:text-gray-900",
                        ),
                    ),
                    class_name="flex items-center justify-between mb-6",
                ),
                rx.el.form(
                    rx.el.div(
                        rx.el.div(
                            rx.el.label(
                                "Nome",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="name",
                                default_value=SettingsState.current_user_edit[
                                    "name"
                                ],
                                key=SettingsState.current_user_edit["id"]
                                + "_name",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "E-mail",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.input(
                                name="email",
                                type="email",
                                default_value=SettingsState.current_user_edit[
                                    "email"
                                ],
                                key=SettingsState.current_user_edit["id"]
                                + "_email",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "w-full px-3 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                    "w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                ),
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Perfil de Acesso",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.div(
                                rx.el.select(
                                    rx.el.option("Admin", value="Admin"),
                                    rx.el.option("Editor", value="Editor"),
                                    rx.el.option(
                                        "Visualizador", value="Visualizador"
                                    ),
                                    name="role",
                                    default_value=SettingsState.current_user_edit[
                                        "role"
                                    ],
                                    key=SettingsState.current_user_edit["id"]
                                    + "_role",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "appearance-none w-full px-4 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                        "appearance-none w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                    ),
                                ),
                                rx.icon(
                                    "chevron-down",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "absolute right-3 top-3 w-4 h-4 text-slate-400 pointer-events-none",
                                        "absolute right-3 top-3 w-4 h-4 text-gray-500 pointer-events-none",
                                    ),
                                ),
                                class_name="relative",
                            ),
                            class_name="mb-4",
                        ),
                        rx.el.div(
                            rx.el.label(
                                "Status",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "block text-sm font-medium text-slate-300 mb-1",
                                    "block text-sm font-medium text-gray-700 mb-1",
                                ),
                            ),
                            rx.el.div(
                                rx.el.select(
                                    rx.el.option("Ativo", value="Ativo"),
                                    rx.el.option("Inativo", value="Inativo"),
                                    name="status",
                                    default_value=SettingsState.current_user_edit[
                                        "status"
                                    ],
                                    key=SettingsState.current_user_edit["id"]
                                    + "_status",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "appearance-none w-full px-4 py-2 bg-[#0B1120] border border-slate-700 rounded-lg text-white",
                                        "appearance-none w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-900",
                                    ),
                                ),
                                rx.icon(
                                    "chevron-down",
                                    class_name=rx.cond(
                                        ThemeState.is_dark,
                                        "absolute right-3 top-3 w-4 h-4 text-slate-400 pointer-events-none",
                                        "absolute right-3 top-3 w-4 h-4 text-gray-500 pointer-events-none",
                                    ),
                                ),
                                class_name="relative",
                            ),
                            class_name="mb-6",
                        ),
                        class_name="grid grid-cols-1 md:grid-cols-2 gap-4",
                    ),
                    rx.el.div(
                        rx.el.button(
                            "Cancelar",
                            type="button",
                            on_click=SettingsState.close_user_modal,
                            class_name=rx.cond(
                                ThemeState.is_dark,
                                "px-4 py-2 border border-slate-700 rounded-lg text-white hover:bg-slate-800",
                                "px-4 py-2 border border-gray-300 rounded-lg text-gray-900 hover:bg-gray-100",
                            ),
                        ),
                        rx.el.button(
                            "Salvar",
                            type="submit",
                            class_name="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg",
                        ),
                        class_name="flex justify-end gap-3",
                    ),
                    on_submit=SettingsState.save_user,
                    reset_on_submit=True,
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "bg-[#1E293B] border border-slate-800 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                    "bg-white border border-gray-200 w-full max-w-2xl rounded-2xl p-6 shadow-2xl",
                ),
            ),
            class_name="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4",
        ),
        rx.fragment(),
    )


def users_section() -> rx.Component:
    return rx.el.div(
        user_modal(),
        rx.el.div(
            rx.el.h2(
                "Usuários e Permissões",
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "text-lg font-semibold text-white",
                    "text-lg font-semibold text-gray-900",
                ),
            ),
            rx.el.button(
                rx.icon("user-plus", class_name="w-4 h-4 mr-2"),
                "Novo Usuário",
                on_click=SettingsState.open_new_user,
                class_name="flex items-center bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg font-medium transition-colors text-sm",
            ),
            class_name="flex items-center justify-between mb-4",
        ),
        rx.cond(
            SettingsState.system_users.length() == 0,
            empty_state(
                "users",
                "Nenhum usuário",
                "Não há usuários cadastrados no sistema.",
            ),
            rx.el.div(
                rx.el.table(
                    rx.el.thead(
                        rx.el.tr(
                            rx.el.th(
                                "Nome",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                    "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                ),
                            ),
                            rx.el.th(
                                "E-mail",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                    "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                ),
                            ),
                            rx.el.th(
                                "Perfil",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                    "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                ),
                            ),
                            rx.el.th(
                                "Status",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                    "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                ),
                            ),
                            rx.el.th(
                                "Ações",
                                class_name=rx.cond(
                                    ThemeState.is_dark,
                                    "px-6 py-3 text-left text-xs font-semibold text-slate-400 uppercase border-b border-slate-700",
                                    "px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase border-b border-gray-200",
                                ),
                            ),
                        ),
                        class_name=rx.cond(
                            ThemeState.is_dark, "bg-slate-800/50", "bg-gray-50"
                        ),
                    ),
                    rx.el.tbody(
                        rx.foreach(SettingsState.system_users, user_row)
                    ),
                    class_name="w-full table-auto border-collapse",
                ),
                class_name=rx.cond(
                    ThemeState.is_dark,
                    "overflow-x-auto border border-slate-700 rounded-xl",
                    "overflow-x-auto border border-gray-200 rounded-xl",
                ),
            ),
        ),
    )