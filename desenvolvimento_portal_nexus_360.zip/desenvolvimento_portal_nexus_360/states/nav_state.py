import reflex as rx


class NavState(rx.State):
    active_tab: str = "Dashboard"

    @rx.event
    def set_tab(self, tab: str):
        self.active_tab = tab