import reflex as rx


class ThemeState(rx.State):
    is_dark: bool = True

    @rx.event
    def toggle_theme(self):
        self.is_dark = not self.is_dark

    @rx.var
    def bg_app(self) -> str:
        return "bg-[#0B1120]" if self.is_dark else "bg-gray-50"

    @rx.var
    def bg_card(self) -> str:
        return "bg-[#1E293B]" if self.is_dark else "bg-white"

    @rx.var
    def text_main(self) -> str:
        return "text-white" if self.is_dark else "text-gray-900"

    @rx.var
    def text_muted(self) -> str:
        return "text-slate-400" if self.is_dark else "text-gray-500"

    @rx.var
    def border_color(self) -> str:
        return "border-slate-800" if self.is_dark else "border-gray-200"