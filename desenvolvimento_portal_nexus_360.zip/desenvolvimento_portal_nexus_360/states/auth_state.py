import reflex as rx
from typing import TypedDict
import json
import uuid


class User(TypedDict):
    email: str
    password: str
    name: str


DEFAULT_USERS = json.dumps([
    {"email": "admin@nexus.edu", "password": "admin", "name": "Administrador"}
])


class AuthState(rx.State):
    _users_json: str = rx.LocalStorage(DEFAULT_USERS, name="auth_users")

    current_user: User = {"email": "", "password": "", "name": ""}
    is_logged_in: bool = False
    login_email: str = ""
    login_password: str = ""
    reg_name: str = ""
    reg_email: str = ""
    reg_password: str = ""
    is_registering: bool = False
    error_message: str = ""

    # ✅ Novos campos para recuperação de senha
    is_recovering: bool = False
    recovery_email: str = ""
    recovery_new_password: str = ""
    recovery_success: bool = False

    @rx.var
    def users(self) -> list[User]:
        try:
            return json.loads(self._users_json)
        except Exception:
            return [{"email": "admin@nexus.edu", "password": "admin", "name": "Administrador"}]

    def _save_users(self, users: list[User]):
        self._users_json = json.dumps(users)

    @rx.event
    def toggle_mode(self):
        self.is_registering = not self.is_registering
        self.is_recovering = False
        self.error_message = ""
        self.recovery_success = False

    # ✅ Alterna para tela de recuperação
    @rx.event
    def show_recovery(self):
        self.is_recovering = True
        self.is_registering = False
        self.error_message = ""
        self.recovery_success = False
        self.recovery_email = ""
        self.recovery_new_password = ""

    # ✅ Volta para o login
    @rx.event
    def back_to_login(self):
        self.is_recovering = False
        self.error_message = ""
        self.recovery_success = False

    @rx.event
    def set_login_email(self, value: str):
        self.login_email = value

    @rx.event
    def set_login_password(self, value: str):
        self.login_password = value

    @rx.event
    def set_reg_name(self, value: str):
        self.reg_name = value

    @rx.event
    def set_reg_email(self, value: str):
        self.reg_email = value

    @rx.event
    def set_reg_password(self, value: str):
        self.reg_password = value

    @rx.event
    def set_recovery_email(self, value: str):
        self.recovery_email = value

    @rx.event
    def set_recovery_new_password(self, value: str):
        self.recovery_new_password = value

    # ✅ Lógica de redefinição de senha
    @rx.event
    def reset_password(self):
        self.error_message = ""
        self.recovery_success = False

        if not self.recovery_email or not self.recovery_new_password:
            self.error_message = "Preencha todos os campos."
            return

        current_users = self.users
        found = False
        for i, user in enumerate(current_users):
            if user["email"] == self.recovery_email:
                current_users[i]["password"] = self.recovery_new_password
                found = True
                break

        if not found:
            self.error_message = "E-mail não encontrado."
            return

        self._save_users(current_users)
        self.recovery_success = True
        self.recovery_email = ""
        self.recovery_new_password = ""

    @rx.event
    def login(self):
        self.error_message = ""
        for user in self.users:
            if (
                user["email"] == self.login_email
                and user["password"] == self.login_password
            ):
                self.current_user = user
                self.is_logged_in = True
                self.login_email = ""
                self.login_password = ""
                return
        self.error_message = "Credenciais inválidas."

    @rx.event
    def register(self):
        self.error_message = ""
        if not self.reg_name or not self.reg_email or not self.reg_password:
            self.error_message = "Preencha todos os campos."
            return

        current_users = self.users
        for user in current_users:
            if user["email"] == self.reg_email:
                self.error_message = "E-mail já cadastrado."
                return

        new_user: User = {
            "email": self.reg_email,
            "password": self.reg_password,
            "name": self.reg_name,
        }

        current_users.append(new_user)
        self._save_users(current_users)

        from desenvolvimento_portal_nexus_360.states.settings_state import SettingsState
        settings = yield self.get_state(SettingsState)
        settings.system_users.append({
            "id": uuid.uuid4().hex[:8],
            "name": self.reg_name,
            "email": self.reg_email,
            "role": "Visualizador",
            "status": "Ativo",
        })

        self.current_user = new_user
        self.is_logged_in = True
        self.reg_name = ""
        self.reg_email = ""
        self.reg_password = ""

    @rx.event
    def logout(self):
        self.is_logged_in = False
        self.current_user = {"email": "", "password": "", "name": ""}