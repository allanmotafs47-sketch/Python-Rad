import reflex as rx
import uuid


class FileUploadState(rx.State):
    @rx.event
    async def handle_upload(self, files: list[rx.UploadFile]):
        from desenvolvimento_portal_nexus_360.states.data_state import DataState

        data_state = await self.get_state(DataState)

        for file in files:
            data = await file.read()
            upload_dir = rx.get_upload_dir()
            upload_dir.mkdir(parents=True, exist_ok=True)

            stored_name = f"{uuid.uuid4().hex[:8]}_{file.name}"
            path = upload_dir / stored_name
            with path.open("wb") as f:
                f.write(data)

            size_mb = len(data) / (1024 * 1024)
            size_str = f"{size_mb:.2f} MB"

            data_state.files.append(
                {
                    "id": uuid.uuid4().hex[:8],
                    "filename": file.name,
                    "stored_name": stored_name,
                    "size": size_str,
                    "description": "",
                }
            )