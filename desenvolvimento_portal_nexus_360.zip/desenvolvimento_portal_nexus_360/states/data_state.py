import reflex as rx
from typing import TypedDict
import uuid


class Project(TypedDict):
    id: str
    name: str
    status: str
    owner: str
    priority: str
    start_date: str
    end_date: str
    notes: str


class Report(TypedDict):
    id: str
    title: str
    date: str
    metrics: str
    project_id: str


class FileData(TypedDict):
    id: str
    filename: str
    stored_name: str
    size: str
    description: str


class Product(TypedDict):
    id: str
    name: str
    price: float
    description: str
    category: str
    status: str
    image_url: str


class AppConfig(TypedDict):
    system_name: str
    version: str


class DataState(rx.State):
    projects: list[Project] = [
        {
            "id": "1",
            "name": "Projeto Alpha",
            "status": "Em Andamento",
            "owner": "Admin",
            "priority": "Alta",
            "start_date": "2023-01-01",
            "end_date": "2023-12-31",
            "notes": "Projeto principal da instituição",
        },
        {
            "id": "2",
            "name": "Sistema Beta",
            "status": "Concluído",
            "owner": "User",
            "priority": "Média",
            "start_date": "2023-05-15",
            "end_date": "2023-08-20",
            "notes": "Sistema de apoio",
        },
    ]

    reports: list[Report] = [
        {
            "id": "1",
            "title": "Relatório Mensal",
            "date": "2023-10-01",
            "metrics": "Produtividade: 85%, Conclusão: 100%",
            "project_id": "1",
        },
    ]

    files: list[FileData] = [
        {
            "id": "1",
            "filename": "documento.pdf",
            "stored_name": "placeholder.pdf",
            "size": "2.4 MB",
            "description": "Documento de requisitos base",
        },
    ]

    products: list[Product] = [
        {
            "id": "1",
            "name": "Licença Estudante",
            "price": 0.0,
            "description": "Acesso básico ao portal educacional",
            "category": "Software",
            "status": "Ativo",
            "image_url": "/placeholder.svg",
        },
    ]

    config: AppConfig = {"system_name": "Nexus 360", "version": "1.0.0"}

    show_project_modal: bool = False
    is_editing_project: bool = False
    editing_project_id: str = ""

    show_report_modal: bool = False
    is_editing_report: bool = False
    editing_report_id: str = ""

    show_product_modal: bool = False
    is_editing_product: bool = False
    editing_product_id: str = ""

    @rx.var
    def total_projects(self) -> str:
        return str(len(self.projects))

    @rx.var
    def total_reports(self) -> str:
        return str(len(self.reports))

    @rx.var
    def total_files(self) -> str:
        return str(len(self.files))

    @rx.var
    def total_products(self) -> str:
        return str(len(self.products))

    @rx.var
    def current_project(self) -> Project:
        if self.is_editing_project:
            for p in self.projects:
                if p["id"] == self.editing_project_id:
                    return p
        return {
            "id": "",
            "name": "",
            "status": "Em Andamento",
            "owner": "",
            "priority": "Média",
            "start_date": "",
            "end_date": "",
            "notes": "",
        }

    @rx.var
    def current_report(self) -> Report:
        if self.is_editing_report:
            for r in self.reports:
                if r["id"] == self.editing_report_id:
                    return r
        return {
            "id": "",
            "title": "",
            "date": "",
            "metrics": "",
            "project_id": "",
        }

    @rx.var
    def current_product(self) -> Product:
        if self.is_editing_product:
            for p in self.products:
                if p["id"] == self.editing_product_id:
                    return p
        return {
            "id": "",
            "name": "",
            "price": 0.0,
            "description": "",
            "category": "",
            "status": "Ativo",
            "image_url": "/placeholder.svg",
        }

    # --- Project Actions ---
    @rx.event
    def open_new_project(self):
        self.is_editing_project = False
        self.editing_project_id = ""
        self.show_project_modal = True

    @rx.event
    def open_edit_project(self, project_id: str):
        self.is_editing_project = True
        self.editing_project_id = project_id
        self.show_project_modal = True

    @rx.event
    def close_project_modal(self):
        self.show_project_modal = False

    @rx.event
    def save_project(self, form_data: dict):
        new_proj: Project = {
            "id": self.editing_project_id
            if self.is_editing_project
            else uuid.uuid4().hex[:8],
            "name": form_data.get("name", ""),
            "status": form_data.get("status", "Em Andamento"),
            "owner": form_data.get("owner", ""),
            "priority": form_data.get("priority", "Média"),
            "start_date": form_data.get("start_date", ""),
            "end_date": form_data.get("end_date", ""),
            "notes": form_data.get("notes", ""),
        }

        if self.is_editing_project:
            for i, p in enumerate(self.projects):
                if p["id"] == self.editing_project_id:
                    self.projects[i] = new_proj
        else:
            self.projects.append(new_proj)
        self.show_project_modal = False

    @rx.event
    def delete_project(self, project_id: str):
        self.projects = [p for p in self.projects if p["id"] != project_id]

    # --- Report Actions ---
    @rx.event
    def open_new_report(self):
        self.is_editing_report = False
        self.editing_report_id = ""
        self.show_report_modal = True

    @rx.event
    def open_edit_report(self, report_id: str):
        self.is_editing_report = True
        self.editing_report_id = report_id
        self.show_report_modal = True

    @rx.event
    def close_report_modal(self):
        self.show_report_modal = False

    @rx.event
    def save_report(self, form_data: dict):
        new_rep: Report = {
            "id": self.editing_report_id
            if self.is_editing_report
            else uuid.uuid4().hex[:8],
            "title": form_data.get("title", ""),
            "date": form_data.get("date", ""),
            "metrics": form_data.get("metrics", ""),
            "project_id": form_data.get("project_id", ""),
        }

        if self.is_editing_report:
            for i, r in enumerate(self.reports):
                if r["id"] == self.editing_report_id:
                    self.reports[i] = new_rep
        else:
            self.reports.append(new_rep)
        self.show_report_modal = False

    @rx.event
    def delete_report(self, report_id: str):
        self.reports = [r for r in self.reports if r["id"] != report_id]

    # --- Product Actions ---
    @rx.event
    def open_new_product(self):
        self.is_editing_product = False
        self.editing_product_id = ""
        self.show_product_modal = True

    @rx.event
    def open_edit_product(self, product_id: str):
        self.is_editing_product = True
        self.editing_product_id = product_id
        self.show_product_modal = True

    @rx.event
    def close_product_modal(self):
        self.show_product_modal = False

    @rx.event
    def save_product(self, form_data: dict):
        price_str = form_data.get("price", "0")
        new_prod: Product = {
            "id": self.editing_product_id
            if self.is_editing_product
            else uuid.uuid4().hex[:8],
            "name": form_data.get("name", ""),
            "price": float(price_str) if price_str else 0.0,
            "description": form_data.get("description", ""),
            "category": form_data.get("category", ""),
            "status": form_data.get("status", "Ativo"),
            "image_url": form_data.get("image_url", "/placeholder.svg"),
        }

        if self.is_editing_product:
            for i, p in enumerate(self.products):
                if p["id"] == self.editing_product_id:
                    self.products[i] = new_prod
        else:
            self.products.append(new_prod)
        self.show_product_modal = False

    @rx.event
    def delete_product(self, product_id: str):
        self.products = [p for p in self.products if p["id"] != product_id]

    # --- File Actions ---
    @rx.event
    def delete_file(self, file_id: str):
        self.files = [f for f in self.files if f["id"] != file_id]