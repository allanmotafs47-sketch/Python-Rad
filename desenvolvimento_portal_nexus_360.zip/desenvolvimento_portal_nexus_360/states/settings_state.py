import reflex as rx
import uuid
from typing import TypedDict


class SystemUser(TypedDict):
    id: str
    name: str
    email: str
    role: str
    status: str


class SettingsState(rx.State):
    active_section: str = "Institucional"

    system_users: list[SystemUser] = [
        {
            "id": "1",
            "name": "Administrador",
            "email": "admin@nexus.edu",
            "role": "Admin",
            "status": "Ativo",
        },
        {
            "id": "2",
            "name": "Usuário Teste",
            "email": "user@nexus.edu",
            "role": "Editor",
            "status": "Inativo",
        },
    ]

    show_user_modal: bool = False
    is_editing_user: bool = False
    editing_user_id: str = ""

    brand_name: str = "Nexus 360"
    brand_color: str = "cyan"

    @rx.event
    def set_section(self, section: str):
        self.active_section = section

    @rx.var
    def current_user_edit(self) -> SystemUser:
        if self.is_editing_user:
            for u in self.system_users:
                if u["id"] == self.editing_user_id:
                    return u
        return {
            "id": "",
            "name": "",
            "email": "",
            "role": "Visualizador",
            "status": "Ativo",
        }

    @rx.event
    def open_new_user(self):
        self.is_editing_user = False
        self.editing_user_id = ""
        self.show_user_modal = True

    @rx.event
    def open_edit_user(self, uid: str):
        self.is_editing_user = True
        self.editing_user_id = uid
        self.show_user_modal = True

    @rx.event
    def close_user_modal(self):
        self.show_user_modal = False

    @rx.event
    def save_user(self, form_data: dict):
        new_u: SystemUser = {
            "id": self.editing_user_id
            if self.is_editing_user
            else uuid.uuid4().hex[:8],
            "name": form_data.get("name", ""),
            "email": form_data.get("email", ""),
            "role": form_data.get("role", "Visualizador"),
            "status": form_data.get("status", "Ativo"),
        }
        if self.is_editing_user:
            for i, u in enumerate(self.system_users):
                if u["id"] == self.editing_user_id:
                    self.system_users[i] = new_u
        else:
            self.system_users.append(new_u)
        self.show_user_modal = False

    @rx.event
    def delete_user(self, uid: str):
        self.system_users = [u for u in self.system_users if u["id"] != uid]

    @rx.event
    def save_institutional(self, form_data: dict):
        self.brand_name = form_data.get("brand_name", self.brand_name)
        self.brand_color = form_data.get("brand_color", self.brand_color)